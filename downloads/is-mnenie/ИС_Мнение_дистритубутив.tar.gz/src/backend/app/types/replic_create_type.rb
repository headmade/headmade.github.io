class ReplicCreateType < Replic
  include BaseType

  def initialize(attrs)
    super

    #self.uuid ||= SecureRandom.uuid
    self.state ||= :validating
  end
end
