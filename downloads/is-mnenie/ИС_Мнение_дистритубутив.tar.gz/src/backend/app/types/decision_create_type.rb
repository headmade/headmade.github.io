class DecisionCreateType < Decision
  include BaseType

  def initialize(attrs)
    super

    #self.uuid ||= SecureRandom.uuid
    self.state ||= :created
  end
end
