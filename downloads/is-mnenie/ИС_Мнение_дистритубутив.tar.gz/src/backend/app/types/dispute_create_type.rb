class DisputeCreateType < Dispute
  include BaseType

  def initialize(attrs)
    super

    self.uuid ||= SecureRandom.uuid
    self.type = 'Dispute::' + self.type.classify.demodulize
    self.state ||= :created
    self.data ||= {}
    self.attachments = S3Service.substitute_url_unescape(self.attachments)
  end

end
