class Replic::Question < Replic
end
