class Replic::Suggestion < Replic
end
