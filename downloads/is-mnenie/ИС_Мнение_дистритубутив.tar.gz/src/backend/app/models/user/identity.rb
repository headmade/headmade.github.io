class User::Identity < ApplicationRecord
  belongs_to :user

  scope :sysop, ->() { find_by!(uid: Rails.application.config.x.system_operator_uid) }
end
