class User < ApplicationRecord
  include Roleable

  has_one :identity
  has_many :disputes

  scope :with_roles, -> (array) { where("roles @> ARRAY[?]::varchar[]", array) unless array.empty? }

  def self.sysop
    #User.find(1)    # TODO: maybe use Rails.application.config.x.system_operator_id or so
    User::Identity.sysop.user
  end
end
