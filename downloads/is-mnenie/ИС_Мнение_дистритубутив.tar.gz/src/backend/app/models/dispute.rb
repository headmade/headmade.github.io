
class Dispute < ApplicationRecord
  belongs_to :user

  has_many :replics
  has_many :suggestions, class_name: 'Replic::Suggestion'
  has_many :questions, class_name: 'Replic::Question'


  scope :with_states, ->(states) { where(state: states) if states.present? }
  scope :notifications, ->() { where("now() between notification_published_at and dispute_started_at") }
  scope :running, ->() { where("now() between dispute_started_at and dispute_ended_at") }
end

