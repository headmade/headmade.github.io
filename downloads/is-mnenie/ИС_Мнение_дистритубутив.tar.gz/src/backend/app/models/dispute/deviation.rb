class Dispute::Deviation < Dispute
end
