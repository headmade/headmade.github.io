class Dispute::Boundary < Dispute
end
