class Dispute::Genplan < Dispute
end
