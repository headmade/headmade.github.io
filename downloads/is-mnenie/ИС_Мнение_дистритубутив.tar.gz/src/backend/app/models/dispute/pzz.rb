class Dispute::Pzz < Dispute
end
