class Dispute::Urvi < Dispute
end
