class Dispute::Planning < Dispute
end
