class Replic < ApplicationRecord
  #self.abstract_class = true
  #self.table_name = :replics

  belongs_to :dispute
  belongs_to :user

  has_many :decisions
end
