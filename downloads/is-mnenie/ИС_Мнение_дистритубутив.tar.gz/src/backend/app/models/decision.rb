class Decision < ApplicationRecord
  #self.abstract_class = true
  #self.table_name = :replics

  belongs_to :user

  belongs_to :replic
end
