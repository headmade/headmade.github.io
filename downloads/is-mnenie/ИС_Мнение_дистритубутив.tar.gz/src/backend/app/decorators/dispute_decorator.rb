class DisputeDecorator < ApplicationDecorator
  delegate_all

  def type
    object.class.to_s.demodulize.underscore
  end

  def attachments
    context[:need_sign_files] ?  S3Service.substitute_url_get(object.attachments) : object.attachments
  end
end
