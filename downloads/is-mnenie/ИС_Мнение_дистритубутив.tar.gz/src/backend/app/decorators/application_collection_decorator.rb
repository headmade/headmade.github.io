class ApplicationCollectionDecorator < Draper::CollectionDecorator
  def as_json
    {
      data: paged.map{|item| decorate_item(item)},
      meta: meta,
    }.as_json
  end

  def paged
    @paged ||= object.page(context[:page]).per(context[:per])
  end
  def meta
    @meta ||= {
      total_records: object.count,
      total_pages: paged.total_pages,
    }
  end
end
