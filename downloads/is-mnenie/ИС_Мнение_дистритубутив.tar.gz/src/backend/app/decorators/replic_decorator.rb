class ReplicDecorator < ApplicationDecorator
  delegate_all

  def type
    object.class.to_s.demodulize.underscore
  end

  def data
    context[:need_data] ? S3Service.substitute_url_get(object.data) : nil
  end

  def text
    object.data['text']
  end

  def decisions
    object.decisions.decorate.as_json
  end

  def as_json(options = {})
    super({methods: %i(text decisions)}.merge(options))
  end
end
