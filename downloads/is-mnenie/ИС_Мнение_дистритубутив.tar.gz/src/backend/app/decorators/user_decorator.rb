class UserDecorator < ApplicationDecorator
  delegate :name, :surname, :patronymic_name, :mobile, :email, :title, :full_name, :gender, to: :identity

  decorates_association :identity

  def esia_id
    identity&.uid
  end

  def esia_roles()
    @esia_roles ||= identity&.data&.dig('info','roles')
  end

  def sys_op?
    @sys_op = identity[:uid] == Rails.application.config.x.system_operator_uid if @sys_op.nil?
    @sys_op
  end

  def agent
    data = (Agent.find_by(mobile: mobile)&.decorate || self).as_json(nil).with_indifferent_access
    # follow agent json-schema definition
    data.slice(:email, :mobile, :passport_number).merge(fio: data.slice(:name, :surname, :patronymic_name))
  end

  def as_json(_=nil)
    super.except('password_digest').compact.merge(
      email: email,
      mobile: mobile,
      name: name,
      surname: surname,
      patronymic_name: patronymic_name,
      gender: gender,
      full_name: full_name,
      title: title,
    )
  end

end
