class ApplicationDecorator < Draper::Decorator
  delegate_all

  def title
    name
  end
end
