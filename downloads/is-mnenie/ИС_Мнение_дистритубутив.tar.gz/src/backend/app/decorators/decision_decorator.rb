class DecisionDecorator < ApplicationDecorator
  delegate_all

  def text
    [object.data['response'], object.data['text']].join
  end

  # TODO: remove data for non-servant

  def as_json(options = {})
    super({methods: %i(text)}.merge(options))
  end
end
