class User::IdentityDecorator < ApplicationDecorator

  def email() fetch_info_key('email'); end
  def mobile() fetch_info_key('mobile'); end

  def name() fetch_info_key('first_name'); end
  def surname() fetch_info_key('last_name'); end
  def patronymic_name() fetch_info_key('middle_name'); end

  def gender() fetch_info_key('gender'); end

  def title
    [surname, name&.first.to_s+'.', (patronymic_name.present? ? patronymic_name[0]+'.' : nil)].compact.join(' ')
  end

  def full_name
    [surname, name, patronymic_name].compact.join(' ')
  end

  private

  def fetch_info_key(key)
    case provider
    when 'mobile'
      model.data.dig('uid')
    when 'esia_oauth'
      model.data.dig('info', key.to_s)
    else
      raise 'Unsupported provider: ' + self.inspect
    end
  end

end
