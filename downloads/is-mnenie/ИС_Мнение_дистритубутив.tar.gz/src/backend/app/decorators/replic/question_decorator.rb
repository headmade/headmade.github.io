class Replic::QuestionDecorator < ReplicDecorator
end
