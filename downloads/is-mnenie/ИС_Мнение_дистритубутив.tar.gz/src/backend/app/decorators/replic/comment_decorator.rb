class Replic::CommentDecorator < ReplicDecorator
end
