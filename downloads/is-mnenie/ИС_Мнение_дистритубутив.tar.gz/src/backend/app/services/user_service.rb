class UserService < ApplicationService
  class << self
    def create_regular_user_oauth(uid)
      User.create!(state: :active, roles: %i(user))
    end

    #def create_servant_for_user(user)
      #user_identity = user.decorate.user_identity_esia_oauth.decorate
      #servant_params = {
        #name: user_identity.name,
        #surname: user_identity.surname,
        #patronymic_name: user_identity.patronymic_name
      #}
      #servant = user.servants.find_or_create_by(servant_params)
      #Rails.logger.debug [:create_servant_for_user, 1, user.roles]
      #user.add_roles(:servant)
      #Rails.logger.debug [:create_servant_for_user, 2, user.roles]
      #user.save!
      #user.servant
    #end

    #def init_servant_from_esia(servant, department)

      ##debug
      ## department = Department.find_by_ogrn('1051622218471')

      #servant.passport_ids = (servant.passport_ids + [37,38,49]).uniq

      ##case department.esia_id.to_s
      ##when '1020102075'
        ##Rails.logger.debug [:esia_role, 'уитис']
      ##end

      ## TODO: find their esia_id!
      #case department['ogrn'].to_s
      #when '1021602850884'
        #Rails.logger.debug [:esia_role, 'минкульт']
      #end

      #Rails.logger.debug [:department, :key, :ogrn, department.id, department.key, department.ogrn, department.short_name]
      #department.servants += [servant]

      #case department.key
      #when 'kvb'
        #servant.passport_ids = (servant.passport_ids + [39,40,41,42]).uniq
      #end

      #servant.save!
      #servant

    #end

  end
end
