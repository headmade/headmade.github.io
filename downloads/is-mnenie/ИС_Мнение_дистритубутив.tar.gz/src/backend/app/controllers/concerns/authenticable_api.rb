module AuthenticableApi
  extend ActiveSupport::Concern
  include Authenticable

  def authenticate!
    head :forbidden unless current_user.present?
  end

  def check_role!
    head :forbidden unless current_user&.has_role?(required_role)
  end
end

