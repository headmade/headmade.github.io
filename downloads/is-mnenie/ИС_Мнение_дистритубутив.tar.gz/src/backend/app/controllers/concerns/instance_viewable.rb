module InstanceViewable
  extend ActiveSupport::Concern

  included do
    before_action :prepend_instance_views_path
  end

  protected
  def prepend_instance_views_path
    prepend_view_path(instance_views_path())
  end

  def instance_views_path(instance_name=nil)
    instance_name ||= Rails.application.config.x.instance_name
    ['app/views/instances', instance_name].join('/')
  end

end

