module AuthenticableWeb
  extend ActiveSupport::Concern
  include Authenticable

  def authenticate!
    unless current_user.present?
      session[:original_url] = request.original_url
      redirect_to default_auth_path
    end
  end

  def check_role!
    redirect_to(current_user_main_role_or_root_path) unless current_user&.has_role?(required_role)
  end
end

