module Authenticable
  extend ActiveSupport::Concern

  included do
    include AuthHelper
    include AuthRoleHelper

    before_action :authenticate!
    before_action :check_role!

    helper_method :current_user, :signed_in?, :required_role
    helper_method :default_auth_path
  end

  def default_auth_path
    Rails.application.config.x.instance.auth_path
  end

  def authenticate!
    raise 'must overload'
  end

  def check_role!
    raise 'must overload'
  end

  def required_role
    @required_role ||= self.class.parent.name.demodulize.downcase.to_sym
  end

end

