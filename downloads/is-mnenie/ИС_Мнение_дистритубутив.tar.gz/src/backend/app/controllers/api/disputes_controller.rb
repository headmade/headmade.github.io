class Api::DisputesController < Api::ApplicationController

  before_action :set_disputes

  def index
    render json: @disputes.decorate
  end

  def show
    dispute = @disputes.find(params[:id])

    render json: dispute.decorate(context: {need_sign_files: params[:dispute_mode] != 'notifications'})
  end

  private

  def set_disputes
    @@dispute_classes ||= {
      genplan: Dispute::Genplan,
      pzz: Dispute::Pzz,
      urvi: Dispute::Urvi,
      deviation: Dispute::Deviation,
      planning: Dispute::Planning,
      boundary: Dispute::Boundary,
    }.with_indifferent_access.freeze

    klass = @@dispute_classes[params[:filter]] || Dispute

    @disputes = klass.all
    if params[:dispute_mode] == 'notifications'
      @disputes = @disputes.notifications
    else
      @disputes = @disputes.running
    end

    #@disputes = @disputes.favorite if params[:filter] == 'favorites'
    @disputes = @disputes.none if params[:filter] == 'favorites'
  end
end
