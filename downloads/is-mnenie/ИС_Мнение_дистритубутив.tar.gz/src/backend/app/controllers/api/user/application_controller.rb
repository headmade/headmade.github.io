class Api::User::ApplicationController < Api::ApplicationController
  include AuthenticableApi
end
