class Api::Servant::DisputesController < Api::Servant::ApplicationController

  before_action :set_disputes

  def create
    dispute = @disputes.create!(DisputeCreateType.new(dispute_params).attributes)
    render json: dispute.decorate
  end

  def update
    @disputes.find(params[:id]).update!(DisputeCreateType.new(dispute_params).attributes)
    head :ok
  end

  private

  def set_disputes
    @disputes = current_user.disputes
  end

  def dispute_params
    params.require(:dispute).permit!.to_h
  end

end
