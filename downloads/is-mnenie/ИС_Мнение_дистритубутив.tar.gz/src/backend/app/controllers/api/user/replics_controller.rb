class Api::User::ReplicsController < Api::User::ApplicationController

  before_action :set_disputes
  before_action :set_dispute
  before_action :set_replics

  def create
    address = current_user.identity.data.dig(*%w(info addresses registration addressStr))
    rct = ReplicCreateType.new(replic_params)
    rct[:data]['registration_address'] = address
    replic = @replics.create!(rct.attributes.except('type').merge('user_id' => current_user.id))
    render json: replic.decorate
  end

  private

  def set_disputes
    @disputes = Dispute.all
  end

  def set_dispute
    @dispute = @disputes.find(params[:dispute_id])
  end

  def set_replics
    @replics =
      case params[:dispute_mode]
      when 'disputes'; @dispute.suggestions
      when 'expositions'; @dispute.questions
      end
  end

  def replic_params
    params.require(:replic).permit!.to_h
  end

end
