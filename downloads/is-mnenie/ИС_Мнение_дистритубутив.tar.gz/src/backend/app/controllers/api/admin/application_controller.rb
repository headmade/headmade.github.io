class Api::Admin::ApplicationController < Api::ApplicationController
  include AuthenticableApi
end
