class Api::Servant::ApplicationController < Api::ApplicationController
  include AuthenticableApi
end
