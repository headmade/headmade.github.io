class Api::S3Controller < Api::Servant::ApplicationController

  skip_before_action :check_role!

  def sign
    filename = [params[:guid], params[:objectName]].join('/')
    url = S3Service.sign_file_put(filename, params[:contentType])

    render json: {signedUrl: url}
  end
end
