class Api::ApplicationController < ::ApplicationController
  skip_before_action :verify_authenticity_token

  protected

  def exception(exc)
    logger.info "500: #{exc.message}: " + params.inspect
    head :unprocessable_entity
  end
end
