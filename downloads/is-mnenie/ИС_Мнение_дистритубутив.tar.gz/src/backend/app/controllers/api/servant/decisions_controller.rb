class Api::Servant::DecisionsController < Api::Servant::ApplicationController

  before_action :set_dispute
  before_action :set_replic

  def create
    #replic = @replics.create!(ReplicCreateType.new(replic_params).attributes.except('type').merge('user_id' => current_user.id))
    decision = nil
    Decision.transaction do
      decision = @replic.decisions.create!(DecisionCreateType.new(decision_params).attributes.except('type').merge('user_id' => current_user.id))
      decision_reason = decision.data['decision']

      @replic.update!(state: decision_reason == 'accept' ? :answered : :rejected)
    end

    #render json: @replic.decorate
    render json: decision.decorate
  end

  private

  def set_dispute
    disputes = Dispute.all # current_user.disputes
    @dispute = disputes.find(params[:dispute_id])
  end

  def set_replic
    @replic = @dispute.replics.find(params[:replic_id])
  end

  def decision_params
    params.require(:decision).permit!.to_h
  end

end
