class Api::ReplicsController < Api::ApplicationController

  include AuthHelper
  helper_method :current_user

  before_action :set_disputes
  before_action :set_dispute
  before_action :set_replics

  def index
    render json: @replics.decorate(context: {need_data: current_user&.servant?})
  end

  def before
    @replics = @replics.where('id < ?', params[:id]).order(id: :desc).limit(10)
    index
  end

  private

  def set_disputes
    @disputes = Dispute.all
  end

  def set_dispute
    @dispute = @disputes.find(params[:dispute_id])
  end

  def set_replics
    @replics ||=
      case params[:dispute_mode]
      when 'disputes'; @dispute.suggestions
      when 'expositions'; @dispute.questions
      end

    #Rails.logger.debug [:current_user, current_user]
    if current_user
      unless current_user.servant?
        @replics = @replics.where(state: :answered).or(@replics.where(user_id: current_user.id))
      end
    else
      @replics = @replics.where(state: :answered)
    end
  end

end
