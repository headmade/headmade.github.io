class Web::SessionsController < Web::ApplicationController
  include AuthenticableWeb

  skip_before_action :authenticate!, only: %i(auth destroy user)
  skip_before_action :check_role!

  #layout 'web/session'

  def auth
    provider = params[:provider]
    raise 'Unknown provider: %s' % [provider] unless %w(esia_oauth).include?(provider)

    auth_provider = auth_hash.provider.to_s
    raise 'Provider mismatch: [%s, %s]' % [provider, auth_provider] unless provider == auth_provider

    unless auth_hash.uid.present?
      flash[:error] = 'После проверки пароля сайт Госуслуги запрашивает права доступа для ИС «Общественные обсуждения». Необходимо подтвердить их, иначе вы не сможете использовать ИС «Общественные обсуждения».'
      redirect_to root_url
      return
    end

    if auth_hash.info.trusted

      unless auth_hash.uid.present?
        flash[:error] = 'После проверки пароля сайт Госуслуги запрашивает права доступа для ИС «Общественные обсуждения». Необходимо подтвердить их, иначе вы не сможете использовать ИС «Общественные обсуждения».'
        redirect_to root_url
        return
      end

      identity = nil
      ::User.transaction do
        identity = build_identity()
        unless identity.user.present?
          user = UserService.create_regular_user_oauth(auth_hash.uid)
          identity.user = user
        end
        identity.save! # identity may be "just created" by build_identity()
      end
      session[:provider] = provider

      perform_signin(identity.user)
    else
      redirect_to stranitsa_dlia_non_trusted
    end
  end

  # в production можно заходить (если вообще разрешено) только из predefined hash;
  # в development можно заходить от любого пользователя
  def user
    id = %i(admin servant user).map{|role| [role, ::User.with_roles(role).first.id]}.to_h.with_indifferent_access[params[:id]]

    if !Rails.env.production? && params[:id].present?
      id = if params[:id] == 'new'
        identity = UserIdentity.find(10)
        user = UserService.create_regular_user_oauth(identity.uid)
        identity.user = user
        identity.save!
        user.id
      else
        id ||= params[:id].to_i
      end
    end

    perform_signin(::User.find(id)) if id.present?
  end

  def destroy
    sign_out()
    reset_session()
    if Rails.env.production? && Rails.application.config.x.instance_name != 'demo'
      redirect_to "https://esia.gosuslugi.ru/idp/ext/Logout?client_id=#{Rails.application.config.x.esia.client_id}&redirect_url=#{Rails.application.config.x.base_url}/"
    else
      redirect_to root_path
    end
  end

  def organizations
    unless current_user.present?
      redirect_to default_auth_path
      return
    end
    @esia_roles = current_user.esia_roles()
  end

  def set_organization
    ::User.transaction do
      oid = params['oid'].to_s
      Rails.logger.debug( [:set_organization, current_user.id, 1, current_user.esia_roles()] )
      esia_role = current_user.esia_roles().select{ |er| er['oid'].to_s == oid }.first

      # store selected role
      #identity = current_user.user_identity_esia_oauth
      #identity.data['info']['role'] = esia_role
      #identity.save!

      # TODO: set servant for Rails.application.config.x.servants

      Rails.logger.debug( [:set_organization, current_user.id, 2, esia_role] )
      if esia_role.present?
        session['esia_role'] = esia_role
        #department = Department.find_by_esia_id(esia_role['oid']) || Department.find_by_ogrn(esia_role['ogrn'])
        #if department.present?
          #session[:esia_role] = esia_role
          #session[:department_id] = department.id
          #unless current_servant.present?
            #servant = UserService.create_servant_for_user(current_user)
            #UserService.init_servant_from_esia(servant, department)
          #end
        #else
          #current_user.remove_roles(:servant)
        #end
      else
        #current_user.remove_roles(:servant)
      end
      current_user.save!
    end

    original_url = session[:original_url]
    session[:original_url] = nil

    redirect_to original_url || current_user_main_role_or_root_path()
  end

  private

  def perform_signin(user)
    original_url = session[:original_url] || request.env['omniauth.origin']
    session[:original_url] = nil

    original_url = nil if original_url&.include?(logout_session_path)

    sign_in(user)
    #Rollbar.info('Login successful', login: user.login, time: Time.now.to_s)

    if current_user.esia_roles().present?
      session[:original_url] = original_url if original_url.present?
      redirect_to organizations_session_path()
    else
      redirect_to original_url.present? ? original_url : current_user_main_role_or_root_path()
    end
  end

  def auth_hash
    @auth_hash ||= if params[:provider].present?
      request.env['omniauth.auth']
    end
  end

  def build_identity()
    identity = ::User::Identity.find_or_initialize_by(provider: auth_hash.provider, uid: auth_hash.uid)
    identity[:data] = auth_hash
    return identity
  end

  def session_params
    params.permit!
  end

end

