class Web::WelcomeController < Web::ApplicationController
  include AuthHelper
  include AuthRoleHelper

  helper_method :current_user, :current_user_main_role
  layout 'kiosk', only: [:kiosk]

  def index
    # Rails feature:
    #  "/path.html": format == 'html',
    #  '/path':      format == :html
    #if request.format == :html
      #redirect_to root_path if params[:path].present? # params[:path] comes from "swallow" rule in routes.
    #else
      #head :gone
    #end
  end

  def kiosk
  end
end
