class Web::Admin::WelcomeController < Web::Admin::ApplicationController
  def index
  end
end
