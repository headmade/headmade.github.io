class Web::Servant::ApplicationController < Web::ApplicationController
  #include ActionContextable
  include AuthenticableWeb
  #layout 'web/user'
end
