class Web::Admin::ApplicationController < Web::ApplicationController
  #include ActionContextable
  include AuthenticableWeb
  #layout 'web/user'
end
