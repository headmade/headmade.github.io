require_relative 'boot'

require 'rails/all'

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module DisputeKzn
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 5.2
    config.active_record.schema_format = :sql
    config.active_job.queue_adapter = :sidekiq

    config.time_zone = ENV['TIME_ZONE'] || raise('TIME_ZONE env is not set')

    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration can go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded after loading
    # the framework and any gems in your application.

    config.middleware.insert_before 0, Rack::Cors do
      allow do
        origins '*'
        resource '*', :headers => :any, :methods => [:get, :post, :options]
      end
    end

    config.i18n.default_locale = ENV['DEFAULT_LOCALE'] || :ru
    config.autoload_paths += %W(#{config.root}/app/services)
    config.autoload_paths += %W(#{config.root}/lib)
    config.autoload_paths += %W(#{config.root}/lib/services)

    config.x = Hashie::Mash.new(Rails.application.config_for(:settings))
    config.x.instance = Hashie::Mash.new(Rails.application.config_for('instances/'+config.x.instance_name))

    config.session_store :redis_store,
      key: "_#{Rails.application.class.parent_name.downcase}_session",
      :servers => config.x.redis.sessions_url,
      :expire_after => config.x.session.expire_after

  end
end
