require 'open-uri'
class Webpacker::Manifest
  def load
    JSON.load(open("#{Rails.application.config.action_controller.asset_host}/manifest.json"))
  end
end if Rails.application.config.action_controller.asset_host.present?
#end if Rails.env.production? && Rails.application.config.action_controller.asset_host.present?
