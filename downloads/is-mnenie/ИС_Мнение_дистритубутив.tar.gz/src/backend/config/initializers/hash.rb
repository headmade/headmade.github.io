class Hash
  def deep_values
    values.map {|v| v.respond_to?(:deep_values) ? v.deep_values : v }.flatten
  end
end
