require 'sidekiq/web'
require 'sidekiq/cron/web'

Rails.application.routes.draw do

  namespace :api, defaults: {format: :json} do

    get '/s3/sign', to: 's3#sign'

    namespace :admin do
    end

    namespace :servant do
      #resources :disputes, only: %i(create update) do
        #resources :replics, only: %i() do
          #resources :decisions, only: %i(create)
        #end
      #end
      resources :disputes, only: %i(create update)
      resources :replics, only: %i() do
        resource :decision, only: %i(create update)
      end
    end

    namespace :user do
      constraints(dispute_mode: /disputes|expositions/) do
        post '/:dispute_mode/:dispute_id/:replic_type', to: 'replics#create'
      end
    end

    constraints(dispute_mode: /notifications|disputes|expositions/) do
      get '/:dispute_mode',     to: 'disputes#index'
      get '/:dispute_mode/:id', to: 'disputes#show'
      get '/:dispute_mode/:dispute_id/replics', to: 'replics#index'
      #get '/:dispute_mode/:dispute_id/replics/:id/:before', to: 'replics#before'
    end

  end

  scope module: :web, defaults: {format: :html} do
    root 'welcome#index'
    get '/kiosk', to: 'welcome#kiosk'

    get '/auth/:provider/callback', to: 'sessions#auth'

    resource :session, only: %i() do
      get :logout, to: 'sessions#destroy'
      get :organizations
      patch :organizations, to: 'sessions#set_organization'

      # development/demo feature only!
      get ':id', to: 'sessions#user', as: :user if Rails.application.config.x.session.allow_login_as_any_user
      get '/',   to: 'sessions#user'            if Rails.application.config.x.session.allow_login_as_any_user
    end

    namespace :admin do
      root 'welcome#index'
    end
    namespace :servant do
    end
    namespace :user do
    end
    get "/*path", to: 'welcome#index'
  end

  Sidekiq::Web.set :session_secret, Rails.application.secrets[:secret_key_base]
  mount Sidekiq::Web => '/sidekiq', :constraints => AdminConstraint.new

  health_check_routes

end
