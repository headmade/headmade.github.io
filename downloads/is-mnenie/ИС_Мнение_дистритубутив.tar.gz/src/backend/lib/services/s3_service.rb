class S3Service < ApplicationService

  class << self

    # TODO: check if used?
    def sign_file_get(path, name='main')
      check_init()
      @s3_services_config[name].sign_file_get(path)
    end

    def sign_url_get(url)
      check_init()
      @s3_services_config.values.map{|s| s.sign_url_get(url)}.compact.first
    end

    def sign_file_put(path, content_type, name='main')
      check_init()
      @s3_services_config[name].sign_file_put(path, content_type)
    end

    def substitute_url_get(attrs)
      check_init()
      if attrs.present?
        attrs = attrs.deep_dup
        attrs.deep_values.each {|v| v.replace(S3Service.sign_url_get(v)) if signable_url?(v) }
        attrs
      end
    end

    def substitute_url_unescape(attrs)
      check_init()
      if attrs.present?
        attrs = attrs.deep_dup
        attrs.deep_values.each {|v| v.replace(URI.unescape(v)) if signable_url?(v) }
        attrs
      end
    end

    # TODO: check why need this (probabluy do not)
    def substitute_url_remove_query(attrs)
      check_init()
      attrs = attrs.deep_dup
      attrs.deep_values.each {|v| v.replace(v.split('?').first) if signable_url?(v) }
      attrs
    end

    def signable_url?(url)
      return nil unless url.is_a?(String) && url.starts_with?('http')
      @s3_services_config.values.map{|s| s.signable_url?(url) ? true : nil }.compact.present?
    end

    # TOFIX
    def substiture_url_for_demo(attrs, path)
      url = [@s3_service_url_prefix, path].join
      attrs.deep_values.each {|v| v.replace(url) if v.is_a?(String) && v.start_with?('http') }
      attrs
    end

    private

    def check_init()
      @s3_services_config ||= Rails.application.config.x.s3.map{|key,config| [key, S3Service.new(key)] }.to_h
    end

  end

  def initialize(name)
    # TODO: cannot assign @s3_service_config at the top (for threaded/concurrent execution)
    s3_service_config = Rails.application.config.x.s3[name]
    #Rails.logger.debug ['s3:initialize', name, Rails.application.config.x.s3[name], Rails.application.config.x.s3]
    @s3_service_storage = Fog::Storage.new(
      endpoint: s3_service_config.endpoint,
      provider: 'AWS',
      aws_access_key_id: s3_service_config.aws_access_key_id,
      aws_secret_access_key: s3_service_config.aws_secret_access_key
    )
    @s3_service_options = {path_style: true}
    @s3_service_url_prefix = [s3_service_config.endpoint, s3_service_config.bucket,''].join('/')
    @s3_service_url_prefix_signable = s3_service_config.sign_any_bucket.present? ? s3_service_config.endpoint : @s3_service_url_prefix
    @s3_service_config = s3_service_config
  end

  def sign_file_get(path)
    @s3_service_storage.get_object_url(
      @s3_service_config.bucket,
      path,
      @s3_service_config.upload_url_expire.to_i.seconds.from_now.to_time.to_i,
      @s3_service_options
    )
  end

  def sign_url_get(url)
    return nil unless signable_url?(url)
    path = url[@s3_service_url_prefix.length..-1]
    bucket = @s3_service_config.bucket
    if @s3_service_config.sign_any_bucket.present?
      uri = URI(URI.escape(url))
      path_arr = uri.path.split('/')
      bucket = path_arr[1]
      path = URI.unescape(path_arr[2..-1].join('/'))
    end
    @s3_service_storage.get_object_url(
      bucket,
      path,
      @s3_service_config.upload_url_expire.to_i.seconds.from_now.to_time.to_i,
      @s3_service_options
    )
  end

  def sign_file_put(path, content_type)
    s3_service_headers = {"Content-Type" => content_type, "x-amz-acl" => "public-read"}
    @s3_service_storage.put_object_url(
      @s3_service_config.bucket,
      path,
      @s3_service_config.upload_url_expire.to_i.seconds.from_now.to_time.to_i,
      s3_service_headers,
      @s3_service_options,
    )
  end


  def substitute_url_get(attrs)
    attrs = attrs.deep_dup
    attrs.deep_values.each {|v| v.replace(S3Service.sign_url_get(v)) if signable_url?(v) }
    attrs
  end

  def substitute_url_unescape(attrs)
    attrs = attrs.deep_dup
    attrs.deep_values.each {|v| v.replace(URI.unescape(v)) if signable_url?(v) }
    attrs
  end

  # TODO: check why need this (probabluy do not)
  def substitute_url_remove_query(attrs)
    attrs = attrs.deep_dup
    attrs.deep_values.each {|v| v.replace(v.split('?').first) if signable_url?(v) }
    attrs
  end

  def signable_url?(url)
    url.is_a?(String) && url.starts_with?(@s3_service_url_prefix_signable)
  end

  def substiture_url_for_demo(attrs, path)
    url = [@s3_service_url_prefix, path].join
    attrs.deep_values.each {|v| v.replace(url) if v.is_a?(String) && v.start_with?('http') }
    attrs
  end

end
