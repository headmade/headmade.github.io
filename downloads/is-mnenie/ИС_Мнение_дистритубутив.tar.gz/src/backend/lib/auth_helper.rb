module AuthHelper

  def current_user
    if signed_in?
      if @current_user.blank?
        set_current_user(User.find_by(id: session[:user_id]))
        if @current_user.blank?
          sign_out
        end
      end
    else
      set_current_user(nil)
    end
    @current_user
  end


  def sign_in(user)
    session.clear

    session[:user_id] = user.id
    #cookies.signed[:user_id] = user.id

    set_current_user(nil)
  end

  def sign_out
    #ActionCable.server.disconnect(current_user: @current_user)
    #cookies.delete(:user_id)
    set_current_user(nil)
    session.clear
  end

  def signed_in?
    session[:user_id]
  end

  private
  def set_current_user(cu)
    @current_user = cu&.decorate
    @current_identity = nil
  end
end
