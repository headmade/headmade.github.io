module AuthRoleHelper

  def current_user_main_role
    if signed_in?
      @main_role ||= current_user.roles.first
    end
  end

  def current_user_main_role_path
    if signed_in?
      @current_user_main_role_path ||= begin
        main_role_path = "#{current_user_main_role}_root_path"

        send(main_role_path) if respond_to?(main_role_path)
      end
    end
  end

  def current_user_main_role_or_root_path
    current_user_main_role_path || :root
  end

end
