class CreateReplics < ActiveRecord::Migration[5.2]
  def change
    create_table :replics do |t|
      t.references :dispute, null: false, index: true
      t.references :user, null: false, index: true
      t.string :type, null: false
      t.string :state, null: false, index: true
      t.json :data, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
