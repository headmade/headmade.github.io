class CreateUserIdentities < ActiveRecord::Migration[5.2]
  def change
    create_table :user_identities do |t|
      t.references :user, null: false, index: false
      t.string :provider, null: false
      t.string :uid, null: false
      t.jsonb :data, null: false

      t.timestamps
      t.timestamp :deleted_at

      t.index :user_id, unique: :true
      t.index :uid, unique: :true
    end
  end
end
