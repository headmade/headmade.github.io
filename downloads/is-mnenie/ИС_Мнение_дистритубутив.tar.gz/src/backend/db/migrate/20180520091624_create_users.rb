class CreateUsers < ActiveRecord::Migration[5.2]
  def change
    create_table :users do |t|
      t.string :state, null: false
      t.string :roles, null: false, array: true

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
