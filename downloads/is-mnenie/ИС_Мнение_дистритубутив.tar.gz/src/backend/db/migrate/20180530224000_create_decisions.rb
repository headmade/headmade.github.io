class CreateDecisions < ActiveRecord::Migration[5.2]
  def change
    create_table :decisions do |t|
      t.references :user, null: false, index: true
      t.references :replic, null: false, index: true
      t.string :state, null: false
      t.json :data, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
