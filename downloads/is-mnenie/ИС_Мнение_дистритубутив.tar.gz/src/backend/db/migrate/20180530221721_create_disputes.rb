class CreateDisputes < ActiveRecord::Migration[5.2]
  def change
    create_table :disputes do |t|
      t.uuid :uuid, null: false, index: true
      t.references :user, null: false

      t.string :type, null: false, index: true

      t.string :state, null: false, index: true

      t.json   :notification, null: false

      t.string :customer, null: false
      t.string :organization, null: false
      t.string :organization_address, null: false

      t.string :title_full, null: false
      t.string :title_short, null: false
      t.string :object_description, null: false

      t.json :data, null: false

      t.timestamp :notification_published_at, null: false
      t.timestamp :dispute_started_at, null: false
      t.timestamp :dispute_ended_at, null: false
      t.timestamp :protocolled_at, null: false
      t.timestamp :conclusion_prepared_at, null: false
      t.timestamp :conclusion_published_at, null: false

      t.string :system_location, null: false
      t.string :system_location_schedule, null: false

      t.string :participant_registration_location, null: false
      t.string :participant_registration_location_schedule #, null: false

      t.json   :participants, null: false
      t.json   :attachments, null: false

      t.timestamps
      t.timestamp :deleted_at
    end
  end
end
