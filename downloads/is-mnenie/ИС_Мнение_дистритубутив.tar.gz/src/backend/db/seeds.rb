# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

puts 'Seed begin'

user_sysop = User.new(state: :active, roles: %w(admin))
user_sysop.build_identity(
  provider: :esia_oauth,
  uid: Rails.application.config.x.system_operator_uid,
  data: {},
)
user_sysop.save!

user_servant = User.new(state: :active, roles: %w(servant))
user_servant.build_identity(
  provider: :esia_oauth,
  uid: User.count+1,
  data: {},
)
user_servant.save!

user_user_1 = User.new(state: :active, roles: %w(user))
user_user_1.build_identity(
  provider: :esia_oauth,
  uid: User.count+1,
  data: {},
)
user_user_1.save!

user_user_2 = User.new(state: :active, roles: %w(user))
user_user_2.build_identity(
  provider: :esia_oauth,
  uid: User.count+1,
  data: {},
)
user_user_2.save!


attachments = [
  {
    url: 'https://s3.dispute.kzn.ru/uploads-demo/scanned_document.jpg',
    description: 'Проект',
  },
  {
    url: 'https://s3.dispute.kzn.ru/uploads-demo/scanned_document.jpg',
    description: 'Иформационные материалы',
  }
]

participants = {
  living_in_disput_territory: '(указанная территория)'
}

dispute_1 = Dispute::Pzz.create!(
  uuid: SecureRandom.uuid,
  user: user_servant,
  state: :active,
  notification: {
    major_decree_number: '1001',
  },
  organization: 'УАиГ',
  organization_address: 'Груздева, 5',
  title_full: 'О подготовке проекта решения Казанской городской Думы о внесении изменений в карту зон градостроительных регламентов Правил землепользования и застройки (часть II Градостроительного устава г.Казани) в отношении земельных участков, расположенных в Советском районе г.Казани',
  title_short: 'Перезонирование в Советском районе',
  customer: 'Р.Ф.Галявиев, Л.А.Гарипова, Р.Р.Галявиев, Г.М.Миннахметова',
  object_description: 'земельные участки, расположенные в Советском районе г.Казани',
  notification_published_at: Date.yesterday,
  dispute_started_at: Date.tomorrow,
  dispute_ended_at: Date.tomorrow + 1.day,
  protocolled_at: Date.tomorrow + 3.day,
  conclusion_prepared_at: Date.tomorrow + 4.day,
  conclusion_published_at: Date.tomorrow + 5.day,
  system_location: 'Груздева, 5, каб.102',
  system_location_schedule: 'по рабочим дням с 9 до 19',
  participant_registration_location: 'Груздева, 5, каб.333',
  participant_registration_location_schedule: 'с понедельника по пятницу с 10 до 17, перерыв на обед с 12 до 13, каждый 3-ий вторник месяца - нет',
  participants: participants,
  data: {
    rezones: [
      {
        zone: {
          cadastre_number: '16:16:000000:6103',
          area: 263430,
          location: '',
        },
        zone_types_from: ['П1','Р2'],
        zone_type_to: 'Р2',
      },
      {
        zone: {
          cadastre_number: '16:16:080503:503',
          area: 19702,
          location: '',
        },
        zone_types_from: ['П1','Р2'],
        zone_type_to: 'Р2',
      },
      {
        zone: {
          cadastre_number: '16:16:080503:6331',
          area: 18442,
          location: '',
        },
        zone_types_from: ['П1','Р2'],
        zone_type_to: 'Р2',
      },
      {
        zone: {
          cadastre_number: '16:16:080503:50',
          area: 5291,
          location: '',
        },
        zone_types_from: ['СХ','Р2'],
        zone_type_to: 'Р2',
      },
      {
        zone: {
          cadastre_number: '16:16:080503:425',
          area: 747,
          location: '',
        },
        zone_types_from: ['СХ','Р2'],
        zone_type_to: 'Р2',
      },
      {
        zone: {
          cadastre_number: '16:16:080503:6349',
          area: 44,
          location: '',
        },
        zone_types_from: ['СХ','Р2'],
        zone_type_to: 'Р2',
      },
      {
        zone: {
          cadastre_number: '16:16:080503:6350',
          area: 13226,
          location: '',
        },
        zone_types_from: ['СХ','Р2'],
        zone_type_to: 'Р2',
      },
    ],
    target: 'для строительства магазина',
  },
  attachments: attachments,
)

dispute_1.questions.create!(user: user_user_1, state: :validating, data: {text: 'нормальный вопрос? (1)'})
dispute_1.questions.create!(user: user_user_1, state: :validating, data: {text: 'странный вопрос? (1)'})
dispute_1.questions.create!(user: user_user_1, state: :validating, data: {text: 'кто виноват? (1)'})
dispute_1.questions.create!(user: user_user_1, state: :validating, data: {text: 'что делать? (1)'})

dispute_1.suggestions.create!(user: user_user_1, state: :validating, data: {text: 'послать на небо (1)'})
dispute_1.suggestions.create!(user: user_user_1, state: :validating, data: {text: 'послать за звёздочкой (1)'})

dispute_2 = Dispute::Urvi.create!(
  uuid: SecureRandom.uuid,
  user: user_servant,
  state: :active,
  notification: {
    major_decree_number: '1002',
  },
  organization: 'УАиГ',
  organization_address: 'Груздева, 5',
  title_full: 'О предоставлении разрешения на условно разрешенный вид использования земельного участка по ул.Гагарина – паркинги на отдельном земельном участке',
  title_short: 'УРВИ - 2',
  customer: 'Котляревский Эдуард Ефимович',
  object_description: 'земельный участок по ул.Гагарина – паркинги на отдельном земельном участке',
  notification_published_at: Date.yesterday,
  dispute_started_at: Date.today,
  dispute_ended_at: Date.tomorrow + 1.day,
  protocolled_at: Date.tomorrow + 3.day,
  conclusion_prepared_at: Date.tomorrow + 4.day,
  conclusion_published_at: Date.tomorrow + 5.day,
  system_location: 'Груздева, 5, каб.102',
  system_location_schedule: 'по рабочим дням с 9 до 19',
  participant_registration_location: 'Груздева, 5, каб.333',
  participant_registration_location_schedule: 'с понедельника по пятницу с 10 до 17, перерыв на обед с 12 до 13, каждый 3-ий вторник месяца - нет',
  participants: participants,
  data: {
    zones: [
      {
        cadastre_number: '16:50:110104:159',
        area: 2171,
        location: 'по ул.Гагарина',
      },
    ],
    permitted_use_code: '4.9',
    zone_type: 'Ж4',
  },
  attachments: attachments,
)

dispute_2.questions.create!(user: user_user_1, state: :validating, data: {text: 'нормальный вопрос? (2)', attachments: attachments})
dispute_2.questions.create!(user: user_user_1, state: :validating, data: {text: 'странный вопрос? (2)'})
dispute_2.questions.create!(user: user_user_1, state: :validating, data: {text: 'кто виноват? (2)'})
dispute_2.questions.create!(user: user_user_1, state: :validating, data: {text: 'что делать? (2)'})

dispute_2.suggestions.create!(user: user_user_1, state: :validating, data: {text: 'послать на небо (2)'})
dispute_2.suggestions.create!(user: user_user_1, state: :validating, data: {text: 'послать за звёздочкой (2)'})

r = dispute_2.questions.first
r.decisions.create!(user: user_user_1, state: :created, data: {text: 'ну да'})
r.update(state: :answered)

r = dispute_2.suggestions.last
r.decisions.create!(user: user_user_1, state: :created, data: {text: 'не стоит'})
r.update(state: :answered)

dispute_3 = Dispute::Deviation.create!(
  uuid: SecureRandom.uuid,
  user: user_servant,
  state: :notification,
  notification: {
    major_decree_number: '1003',
  },
  organization: 'УАиГ',
  organization_address: 'Груздева, 5',
  title_full: 'О предоставлении разрешений на отклонение от предельных параметров разрешенного строительства для земельного участка по ул.Гагарина',
  title_short: 'Отклонение от пределов по ул.Гагарина',
  customer: 'Котляревский Эдуард Ефимович',
  object_description: '',
  notification_published_at: Date.yesterday - 1.day,
  dispute_started_at: Date.yesterday,
  dispute_ended_at: Date.today,
  protocolled_at: Date.tomorrow + 3.day,
  conclusion_prepared_at: Date.tomorrow + 4.day,
  conclusion_published_at: Date.tomorrow + 5.day,
  system_location: 'Груздева, 5, каб.102',
  system_location_schedule: 'по рабочим дням с 9 до 19',
  participant_registration_location: 'Груздева, 5, каб.333',
  participant_registration_location_schedule: 'с понедельника по пятницу с 10 до 17, перерыв на обед с 12 до 13, каждый 3-ий вторник месяца - нет',
  participants: participants,
  data: {
    reasons: [''],
    margins: {
      linear: [
        {from: 1, to: 2, distance: 1.25},
        {from: 2, to: 3, distance: 0.5},
        {from: 4, to: 5, distance: 0.5},
        {from: 5, to: 6, distance: 2},
        {from: 7, to: 8, distance: 0.5},
        {from: 8, to: 9, distance: 1.5},
        {from: 8, to: 9, distance: 1.5},
      ],
      radial: [ {center: 3, distance: 3.1415926} ],
    },
    parking: [
      {
        zone: {
          cadastre_number: '16:50:110104:159',
          area: 0,
          location: '',
        },
        count: 108,
      }
    ],
    percentage_of_construction: {
      value: 37.21,
    },
    density_of_construction: {
      value: 25390,
    },
    height: {
      value: 33
    },
  },
  attachments: attachments,
)

dispute_3.questions.create!(user: user_user_1, state: :validating, data: {text: 'нормальный вопрос? (3)'})
dispute_3.questions.create!(user: user_user_1, state: :validating, data: {text: 'странный вопрос? (3)'})
dispute_3.questions.create!(user: user_user_1, state: :validating, data: {text: 'кто виноват? (3)'})
dispute_3.questions.create!(user: user_user_1, state: :validating, data: {text: 'что делать? (3)'})

dispute_3.suggestions.create!(user: user_user_1, state: :validating, data: {text: 'послать на небо (3)'})
dispute_3.suggestions.create!(user: user_user_1, state: :validating, data: {text: 'послать за звёздочкой (3)'})

dispute_4 = Dispute::Deviation.create!(
  uuid: SecureRandom.uuid,
  user: user_servant,
  state: :notification,
  notification: {
    major_decree_number: '1004',
  },
  organization: 'УАиГ',
  organization_address: 'Груздева, 5',
  title_full: 'О предоставлении разрешений на отклонение от предельных параметров разрешенного строительства для земельного участка по ул.Гагарина',
  title_short: 'Отклонение от пределов по ул.Гагарина 24',
  customer: 'Котляревский Эдуард Ефимович',
  object_description: '',
  notification_published_at: Date.tomorrow,
  dispute_started_at: Date.tomorrow + 1.day,
  dispute_ended_at: Date.tomorrow + 2.day,
  protocolled_at: Date.tomorrow + 3.day,
  conclusion_prepared_at: Date.tomorrow + 4.day,
  conclusion_published_at: Date.tomorrow + 5.day,
  system_location: 'Груздева, 5, каб.102',
  system_location_schedule: 'по рабочим дням с 9 до 19',
  participant_registration_location: 'Груздева, 5, каб.333',
  participant_registration_location_schedule: 'с понедельника по пятницу с 10 до 17, перерыв на обед с 12 до 13, каждый 3-ий вторник месяца - нет',
  participants: participants,
  data: {
    reasons: [''],
    margins: {
      linear: [
        {from: 1, to: 2, distance: 1.25},
        {from: 2, to: 3, distance: 0.5},
        {from: 4, to: 5, distance: 0.5},
        {from: 5, to: 6, distance: 2},
        {from: 7, to: 8, distance: 0.5},
        {from: 8, to: 9, distance: 1.5},
        {from: 8, to: 9, distance: 1.5},
      ],
      radial: [ {center: 3, distance: 3.1415926} ],
    },
    parking: [
      {
        zone: {
          cadastre_number: '16:50:110104:159',
          area: 0,
          location: '',
        },
        count: 108,
      }
    ],
    percentage_of_construction: {
      value: 37.21,
    },
    density_of_construction: {
      value: 25390,
    },
    height: {
      value: 33
    },
  },
  attachments: attachments,
)

puts 'Seed end'

