`.find(selector) => ShallowWrapper`
- Find every node in the render tree that matches the provided selector.
- Найдет каждый узел в дереве рендеринга, который соответствует предоставленному селектору.

`.findWhere(predicate) => ShallowWrapper`
- Find every node in the render tree that returns true for the provided predicate function.
- Найдите каждый узел в дереве рендеринга, который возвращает true для предоставленной функции предиката.

`.filter(selector) => ShallowWrapper`
- Remove nodes in the current wrapper that do not match the provided selector.
- Удалите узлы в текущей оболочке, которые не соответствуют предоставленному селектору.

`.filterWhere(predicate) => ShallowWrapper`

- Remove nodes in the current wrapper that do not return true for the provided predicate function.
- Удалите узлы в текущей оболочке, которые не возвращают true для предоставленной функции предиката.

`.hostNodes() => ShallowWrapper`
- Removes nodes that are not host nodes; e.g., this will only return HTML nodes.
- Удаляет узлы, которые не являются узлами узла; например, это приведет только к возврату узлов HTML.

`.contains(nodeOrNodes) => Boolean`
- Возвращает, находится ли данный узел или массив узлов где-то в дереве рендеринга.
- Returns whether or not a given node or array of nodes is somewhere in the render tree.

`.containsMatchingElement(node) => Boolean`
- Возвращает, существует ли данный элемент реагирования в мелком дереве рендеринга.
- Returns whether or not a given react element exists in the shallow render tree.

`.containsAllMatchingElements(nodes) => Boolean`
- Возвращает, существуют или нет все указанные элементы реагирования в мелком дереве рендеринга.
- Returns whether or not all the given react elements exists in the shallow render tree.

`.containsAnyMatchingElements(nodes) => Boolean`
- Возвращает, существует ли один из заданных элементов реакции в мелком дереве рендеринга.
- Returns whether or not one of the given react elements exists in the shallow render tree.

`.equals(node) => Boolean`
- Возвращает, соответствует ли текущее дерево рендеринга данному узлу, исходя из ожидаемого значения.
- Returns whether or not the current render tree is equal to the given node, based on the expected value.

`.matchesElement(node) => Boolean`
- Возвращает, соответствует ли данный элемент реакции мелкому дереву рендеринга.
- Returns whether or not a given react element matches the shallow render tree.

`.hasClass(className) => Boolean`
- Возвращает, имеет ли текущий узел указанное имя класса или нет.
- Returns whether or not the current node has the given class name or not.

`.is(selector) => Boolean`
- Возвращает, соответствует ли текущий узел предоставленному селектору.
- Returns whether or not the current node matches a provided selector.

`.exists() => Boolean`
- Возвращает, существует или нет текущий узел.
- Returns whether or not the current node exists.

`.isEmptyRender() => Boolean`
- Возвращает, возвращает ли текущий компонент значение ложности.
- Returns whether or not the current component returns a falsy value.

`.not(selector) => ShallowWrapper`
- Удалите узлы в текущей оболочке, которые соответствуют предоставленному селектору. (обратный к .filter ())
- Remove nodes in the current wrapper that match the provided selector. (inverse of .filter())

`.children() => ShallowWrapper`
- Получите оболочку со всеми дочерними узлами текущей оболочки.
- Get a wrapper with all of the children nodes of the current wrapper.

`.childAt(index) => ShallowWrapper`
- Возвращает новую оболочку с дочерним элементом по указанному индексу.
- Returns a new wrapper with child at the specified index.

`.parents() => ShallowWrapper`
- Получите оболочку со всеми родителями (предками) текущего узла.
- Get a wrapper with all of the parents (ancestors) of the current node.

`.parent() => ShallowWrapper`
- Получите оболочку с прямым родителем текущего узла.
- Get a wrapper with the direct parent of the current node.

`.closest(selector) => ShallowWrapper`
- Получите оболочку с первым предком текущего узла в соответствии с предоставленным селектором.
- Get a wrapper with the first ancestor of the current node to match the provided selector.

`.shallow([options]) => ShallowWrapper`
- Неглубоко отображает текущий узел и возвращает вокруг него неглубокую обертку.
- Shallow renders the current node and returns a shallow wrapper around it.

`.render() => CheerioWrapper`
- Возвращает CheerioWrapper поддерева текущего узла.
- Returns a CheerioWrapper of the current node's subtree.

`.unmount() => ShallowWrapper`
- Метод, который удаляет компонент.
- A method that un-mounts the component.

`.text() => String`
- Возвращает строковое представление текстовых узлов в текущем дереве рендеринга.
- Returns a string representation of the text nodes in the current render tree.

`.html() => String`
- Возвращает статический HTML-рендеринг текущего узла.
- Returns a static HTML rendering of the current node.

`.get(index) => ReactElement`
- Возвращает узел по предоставленному индексу текущей оболочки.
- Returns the node at the provided index of the current wrapper.

`.getNode() => ReactElement`
- Возвращает базовый узел обертки.
- Returns the wrapper's underlying node.

`.getNodes() => Array<ReactElement>`
- Возвращает базовые узлы оболочки.
- Returns the wrapper's underlying nodes.

`.at(index) => ShallowWrapper`
- Возвращает оболочку узла по предоставленному индексу текущей оболочки.
- Returns a wrapper of the node at the provided index of the current wrapper.

`.first() => ShallowWrapper`
- Возвращает оболочку первого узла текущей оболочки.
- Returns a wrapper of the first node of the current wrapper.

`.last() => ShallowWrapper`
- Возвращает оболочку последнего узла текущей оболочки.
- Returns a wrapper of the last node of the current wrapper.

`.state([key]) => Any`
- Возвращает состояние корневого компонента.
- Returns the state of the root component.

`.context([key]) => Any`
- Возвращает контекст корневого компонента.
- Returns the context of the root component.

`.props() => Object`
- Возвращает реквизиты текущего узла.
- Returns the props of the current node.

`.prop(key) => Any`
- Возвращает именованную опцию текущего узла.
- Returns the named prop of the current node.

`.key() => String`
- Возвращает ключ текущего узла.
- Returns the key of the current node.

`.simulate(event[, data]) => ShallowWrapper`
- Имитирует событие на текущем узле.
- Simulates an event on the current node.

`.setState(nextState) => ShallowWrapper`
- Вручную устанавливает состояние корневого компонента.
- Manually sets state of the root component.

`.setProps(nextProps) => ShallowWrapper`
- Вручную устанавливает реквизиты корневого компонента.
- Manually sets props of the root component.

`.setContext(context) => ShallowWrapper`
- Вручную устанавливает контекст корневого компонента.
- Manually sets context of the root component.

`.instance() => ReactComponent`
- Возвращает экземпляр корневого компонента.
- Returns the instance of the root component.

`.update() => ShallowWrapper`
- Вызывает .forceUpdate () на экземпляре корневого компонента.
- Calls .forceUpdate() on the root component instance.

`.debug() => String`
- Возвращает строковое представление текущего мелкого дерева рендеринга для целей отладки.
- Returns a string representation of the current shallow render tree for debugging purposes.

`.type() => String|Function`
- Возвращает тип текущего узла оболочки.
- Returns the type of the current node of the wrapper.

`.name() => String`
- Возвращает имя текущего узла оболочки.
- Returns the name of the current node of the wrapper.

`.forEach(fn) => ShallowWrapper`
- Итерации через каждый узел текущей оболочки и выполнение предоставленной функции
- Iterates through each node of the current wrapper and executes the provided function

`.map(fn) => Array`
- Отображает текущий массив узлов в другой массив.
- Maps the current array of nodes to another array.

`.reduce(fn[, initialValue]) => Any`
- Уменьшает текущий массив узлов до значения
- Reduces the current array of nodes to a value

`.reduceRight(fn[, initialValue]) => Any`
- Уменьшает текущий массив узлов до значения справа налево.
- Reduces the current array of nodes to a value, from right to left.

`.slice([begin[, end]]) => ShallowWrapper`
- Возвращает новую оболочку с подмножеством узлов исходной оболочки в соответствии с правилами массива Array #.
- Returns a new wrapper with a subset of the nodes of the original wrapper, according to the rules of Array#slice.

`.tap(intercepter) => Self`
- Встает в цепочку методов обертки. Полезно для отладки.
- Taps into the wrapper method chain. Helpful for debugging.

`.some(selector) => Boolean`
- Возвращает, соответствует ли какой-либо из узлов в обертке предоставленному селектору.
- Returns whether or not any of the nodes in the wrapper match the provided selector.

`.someWhere(predicate) => Boolean`
- Возвращает, проходит ли какой-либо из узлов в обертке переданная предикатная функция.
- Returns whether or not any of the nodes in the wrapper pass the provided predicate function.

`.every(selector) => Boolean`
- Возвращает, соответствуют ли все узлы в оболочке предоставленному селектору.
- Returns whether or not all of the nodes in the wrapper match the provided selector.

`.everyWhere(predicate) => Boolean`
- Возвращает, передают ли все узлы в обертке предоставленную предикатную функцию.
- Returns whether or not all of the nodes in the wrapper pass the provided predicate function.

`.dive([options]) => ShallowWrapper`
- Неглубоко отобразите один не-DOM-тип текущей оболочки и верните оболочку вокруг результата.
- Shallow render the one non-DOM child of the current wrapper, and return a wrapper around the result.
