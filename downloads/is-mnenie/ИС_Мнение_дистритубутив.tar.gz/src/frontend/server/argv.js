module.exports = require('minimist')(process.argv.slice(2))
