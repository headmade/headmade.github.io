import React, {PureComponent} from 'react'
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {Col} from 'react-gosuslugi'
import {createStructuredSelector} from "reselect"
import {makeSelectDisputes} from "../DisputeList/selectors"
import {loadDisputes} from "../DisputeList/actions"
import SuperList from '../../components/SuperList/index'

class ExpositionList extends PureComponent {
  static propTypes = {
    // from connect
    disputes: PropTypes.object.isRequired,
    onLoadDisputes: PropTypes.func.isRequired
  }

  componentDidMount() {
    this.props.onLoadDisputes()
  }

  render() {
    const {disputes} = this.props
    const superDisputes = disputes.get("disputes").toJS()
    return (
      <Col xs={6} sm={8} md={18} lg={18}>
        <div className="disputes">
          <ul className="disputes__list">
            {superDisputes && superDisputes.length > 0 ? superDisputes.map(dispute => {
              return (
                <SuperList
                  key={dispute.id}
                  id={dispute.id}
                  mode='expositions'
                  title={dispute.title_short}
                  state={dispute.state}
                  organization={dispute.organization}
                  dispute_started_at={dispute.dispute_started_at}
                  dispute_ended_at={dispute.dispute_ended_at}
                  // customer={dispute.customer}
                  // object_description={dispute.object_description}
                  // remaining={dispute.remaining}
                  // favorite={dispute.favorite}
                  // onToggleFavorite={onToggleFavorite}
                  // tags={dispute.tags}
                />
              )
            }) : <h3>Сейчас не проводятся экспозиции общественных обсуждений</h3>}
          </ul>
        </div>
      </Col>
    )
  }
}

const mapStateToProps = () => createStructuredSelector({
  disputes: makeSelectDisputes()
})

const mapDispatchToProps = (dispatch) => {
  return {
    onLoadDisputes: () => {
      dispatch(loadDisputes('expositions'))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ExpositionList)
