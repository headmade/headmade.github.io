/*
 * NotFoundPage Messages
 *
 * This contains all the text for the NotFoundPage component.
 */
import { defineMessages } from 'react-intl'

export default defineMessages({
  problemNotFound: {
    id: 'app.containers.NotFoundPage.problemNotFound',
    defaultMessage: 'Странница не найдена!'
  },
  problemError: {
    id: 'app.containers.NotFoundPage.problemError',
    defaultMessage: 'Что-то пошло не так (('
  },
  button: {
    id: 'app.containers.NotFoundPage.button',
    defaultMessage: 'На главную'
  }
})
