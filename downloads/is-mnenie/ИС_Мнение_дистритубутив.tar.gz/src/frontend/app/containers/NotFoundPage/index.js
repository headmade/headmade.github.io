import React from 'react'
import {FormattedMessage} from 'react-intl'
import PropTypes from "prop-types"
import {Link} from 'react-router-dom'
import {Col, Button} from 'react-gosuslugi'
import messages from './messages'
import './ContentError.sass'

export default class NotFound extends React.PureComponent {
  static propTypes = {
    problem: PropTypes.string
  }

  render() {
    return (
      <Col xs={6} sm={8} md={18} lg={18}>
        <div className="wrapper-error">
          <div className="error__message">
            <h1 className="base-caption">
              {this.props.problem === "error" ?
                <FormattedMessage {...messages.problemError} />
                :
                <FormattedMessage {...messages.problemNotFound} />
              }
            </h1>
            <p>
              <Link to={`/`} >
                <Button bsSize="lg">
                  <FormattedMessage {...messages.button} />
                </Button>
              </Link>
            </p>
          </div>
          <div className="error__img">
            <img src={require("./face.gif")} alt="Ошибка" />
          </div>
        </div>
      </Col>
    )
  }
}
