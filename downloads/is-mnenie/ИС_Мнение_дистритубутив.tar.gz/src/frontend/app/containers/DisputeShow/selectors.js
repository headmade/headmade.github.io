import {createSelector} from 'reselect'

const selectDispute = (state) => state.get("dispute")

const makeSelectDispute = () => createSelector(selectDispute, (dispute) => {
  return dispute.get("dispute").toJS()
})

export {
  selectDispute,
  makeSelectDispute
}
