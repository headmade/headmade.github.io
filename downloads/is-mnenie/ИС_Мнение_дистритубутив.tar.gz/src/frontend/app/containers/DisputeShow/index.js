import React, {Component} from 'react'
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {Col} from 'react-gosuslugi'
import {createStructuredSelector} from "reselect"
import {makeSelectDispute} from "./selectors"
import {mapToComponents} from '../../components/SuperShow'
import Comments from '../Comments/index'
import {loadDispute} from "./actions"
import {makeSelectUser} from "../App/selectors"

class DisputeShow extends Component {
  static propTypes = {
    // from connect
    user: PropTypes.object,
    match: PropTypes.object.isRequired,
    dispute: PropTypes.object.isRequired,
    onAddComment: PropTypes.func,
    onLoadDispute: PropTypes.func
  }

  componentDidMount() {
    this.props.onLoadDispute(this.props.match.params.id)
  }

  render() {
    const {dispute, onAddComment, match, user} = this.props
    const mode = match.path.match(/\/(\w+)\/:id/)[1]
    const Component = mapToComponents(mode)
    const userRole = user.get('type')
    return (
      <Col xs={6} sm={8} md={18} lg={18}>
        <Component
          dispute={dispute}
          key={dispute.id}
          mode={mode}
          userRole={userRole}
          // onToggleFavorite={onToggleFavorite}
          path={match.path}
        />
        {dispute.id && <Comments type={dispute.type} dispute={dispute} onAddComment={onAddComment} disputeId={dispute.id} mode={mode} />}
      </Col>
    )
  }
}

const mapStateToProps = () => createStructuredSelector({
  dispute: makeSelectDispute(),
  user: makeSelectUser()
})

const mapDispatchToProps = (dispatch) => {
  return {
    onLoadDispute: (disputeId) => {
      dispatch(loadDispute(disputeId))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(DisputeShow)
