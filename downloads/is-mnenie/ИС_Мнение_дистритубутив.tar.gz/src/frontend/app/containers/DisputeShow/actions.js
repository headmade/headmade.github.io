import {RSAA} from 'redux-api-middleware'
import {FAIL, LOAD_DISPUTE, START, SUCCESS} from '../App/constants'

export function loadDispute(id) {
  return {
    [RSAA]: {
      endpoint: `/api/disputes/${id}.json`,
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      types: [
        LOAD_DISPUTE + START,
        LOAD_DISPUTE + SUCCESS,
        LOAD_DISPUTE + FAIL
      ]
    }
  }
}
