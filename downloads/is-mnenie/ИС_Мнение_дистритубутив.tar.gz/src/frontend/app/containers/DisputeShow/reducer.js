import {fromJS} from 'immutable'
import {
  LOAD_DISPUTE, START, FAIL, SUCCESS
} from '../App/constants'

const initialStateDisputes = fromJS({
  dispute: {}
})

export function disputeReducer(statusDisputes = initialStateDisputes, action) {
  const {type, error, payload} = action

  switch (type) {
    case LOAD_DISPUTE + START:
      return statusDisputes.set('loading', true)

    case LOAD_DISPUTE + FAIL:
      return statusDisputes
        .set('loading', false)
        .set('error', error)

    case LOAD_DISPUTE + SUCCESS:
      return statusDisputes
        .set('loading', false)
        .set('loaded', true)
        .set('dispute',  fromJS(payload))

  }
  return statusDisputes
}
