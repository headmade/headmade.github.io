import { RSAA } from 'redux-api-middleware'
import {ADD_FORM_DISPUTE, START, FAIL} from '../App/constants'

export default function addFormDispute(formData) {
  return {
    [RSAA]: {
      endpoint: '/api/servant/disputes',
      method: 'POST',
      types: [ADD_FORM_DISPUTE + START, ADD_FORM_DISPUTE, ADD_FORM_DISPUTE + FAIL],
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({dispute: formData.toJS()})
    }
  }
}
