import {defineMessages} from 'react-intl'

export default defineMessages({
  title: {
    id: 'app.containers.DisputeNew.title',
    defaultMessage: 'Регистрация:'
  },
  selectTitle: {
    id: 'app.containers.DisputeNew.selectTitle',
    defaultMessage: 'Выберите тип:'
  },
  select:{
    id: 'app.containers.DisputeNew.select',
    defaultMessage: 'Выбрать'
  },
  button: {
    id: 'app.containers.DisputeNew.button',
    defaultMessage: 'Зарегистрировать'
  },
  cancelButton: {
    id: 'app.containers.DisputeNew.cancelButton',
    defaultMessage: 'Отменить'
  }
})
