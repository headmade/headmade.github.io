import React, {Component} from 'react'
import PropTypes from 'prop-types'
import {connect} from 'react-redux'
import { push } from 'react-router-redux'
import {fromJS} from 'immutable'
import {createStructuredSelector} from "reselect"
import {Col, Button} from 'react-gosuslugi'
import {FormattedMessage} from 'react-intl'
import UIForm from "../../components/Form/ui_form"
import schemas from "../../components/Form/schemas"
import prepareSchema from "../../components/Form/prepare_schema"
import StatusShow from "../../components/StatusShow"
import addFormDispute from "./actions"
import messages from './messages'
import tagsMessages from '../Tags/messages'
import {makeSelectDisputes} from "../DisputeList/selectors"
import {CLEAR, ADD_FORM_DISPUTE, CLEAR_STATUS} from '../App/constants'
import "../../components/Favorites/Favorite.sass"

class DisputeNew extends Component {
  static propTypes = {
    disputes: PropTypes.object,
    //from connect
    onAddFormDispute: PropTypes.func.isRequired,
    clearStatus: PropTypes.func.isRequired,
    changeUrl: PropTypes.func.isRequired
  }

  constructor(props){
    super(props)
    this.state = {type: null}
    this.types = [
      {key: 'genplan', name: <FormattedMessage {...tagsMessages.genplan} />, description: "какой-то текст про genplan, объясняющий что и как"},
      {key: 'pzz', name: <FormattedMessage {...tagsMessages.pzz} />, description: "какой-то текст про pzz, объясняющий что и как"},
      {key: 'deviation', name: <FormattedMessage {...tagsMessages.deviation} />, description: "какой-то текст про deviation, объясняющий что и как"},
      {key: 'urvi', name: <FormattedMessage {...tagsMessages.urvi} />, description: "какой-то текст про urvi, объясняющий что и как"},
      {key: 'planning', name: <FormattedMessage {...tagsMessages.planning} />, description: "какой-то текст про planning, объясняющий что и как"},
      {key: 'boundary', name: <FormattedMessage {...tagsMessages.boundary} />, description: "какой-то текст про boundary, объясняющий что и как"}
    ]
  }

  componentDidMount(){
    this.props.clearStatus()
  }

  onSubmit = (event) => {
    const formData = event.formData
    formData["type"] = this.state.type
    this.props.onAddFormDispute(fromJS(formData))
  }

  selectType(key, name) {
    this.setState({type: key, name: name})
  }

  dropType = ()=>{
    this.props.clearStatus()
    this.setState({type: null, name: null})
  }

  selectSchema(type) {
    return schemas[type]
  }

  render() {
    const {disputes} = this.props
    const newDispute = disputes.get('newDispute')
    const formSent = disputes.get('sent')
    const formSending = disputes.get('sending')
    const formError = disputes.get('error')
    if (newDispute.id) {
      this.props.changeUrl(`/`)
    }
    if (!this.state.type){
      return (<Col xs={6} sm={8} md={18} lg={18}>
        <div className="disputes">
          <h2><FormattedMessage {...messages.selectTitle} /></h2>
          <ul className="disputes__list">
            {this.types.reverse().map((type)=>{
              return (<li className="disputes__item" key={type.key}>
                <div className="disputes__header">
                  <h4 className="disputes__title">{type.name}</h4>
                </div>
                <p className="disputes__text">{type.description}</p>
                <div className="favorite">
                  <div className="favorite__item" onClick={this.selectType.bind(this, type.key, type.name)}>
                    <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 459 459" style={{stroke: "#000000", strokeWidth: "10px"}}>
                      <path style={{fill: "#fff"}} d="M459,216.75L280.5,38.25v102c-178.5,25.5-255,153-280.5,280.5C63.75,331.5,153,290.7,280.5,290.7v104.55L459,216.75z" />
                    </svg>
                    <FormattedMessage {...messages.select} />
                  </div>
                </div>
              </li>)
            })}
          </ul>
        </div>
      </Col>)
    }
    return (
      <Col xs={6} sm={8} md={18} lg={18}>
        <div className="disputes">
          <h2><FormattedMessage {...messages.title} /> {this.state.name}</h2>
          <UIForm onSubmit={this.onSubmit} schema={prepareSchema(this.selectSchema(this.state.type))}>
            <div className="buttonWrapper">
              <Button bsStyle="success" bsSize="large" type="submit" disabled={formSending}>
                <StatusShow sending={formSending} sent={formSent} error={formError} />
                <FormattedMessage {...messages.button} />
              </Button>
              <Button bsStyle="danger" bsSize="large" onClick={this.dropType}><FormattedMessage {...messages.cancelButton} /></Button>
            </div>
          </UIForm>
        </div>
      </Col>
    )
  }
}

const mapStateToProps = () => createStructuredSelector({
  disputes: makeSelectDisputes()
})

const mapDispatchToProps = (dispatch) => {
  return {
    clearStatus: () => {
      dispatch({type: ADD_FORM_DISPUTE + CLEAR_STATUS})
    },
    onAddFormDispute: (formData) => {
      dispatch(addFormDispute(formData))
    },
    changeUrl: (url) => {
      dispatch(push(url))
      dispatch({type: CLEAR + ADD_FORM_DISPUTE})
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(DisputeNew)
