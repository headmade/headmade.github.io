import {defineMessages} from 'react-intl'

export default defineMessages({
  NoDisputes: {
    id: 'app.containers.DisputeList.NoDisputes',
    defaultMessage: 'Сейчас не проводятся общественные обсуждения'
  }
})
