import {createSelector} from 'reselect'

const selectDisputes = (state) => state.get('disputes')

const makeSelectDisputes = () => createSelector(selectDisputes, disputes => disputes)

export {
  selectDisputes,
  makeSelectDisputes
}
