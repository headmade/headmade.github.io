import {RSAA} from 'redux-api-middleware'
import {LOAD_DISPUTES, SUCCESS, FAIL, START} from '../App/constants' //TOGGLE_FAVORITE,

// export function toggleFavorite(disputeId) {
//   return {
//     type: TOGGLE_FAVORITE,
//     payload: {disputeId}
//   }
// }

export function loadDisputes(type='disputes', filter='') {
  return {
    [RSAA]: {
      endpoint: `/api/${type}?filter=${filter}`,
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      types: [
        LOAD_DISPUTES + START,
        LOAD_DISPUTES + SUCCESS,
        LOAD_DISPUTES + FAIL
      ]
    }
  }
}

