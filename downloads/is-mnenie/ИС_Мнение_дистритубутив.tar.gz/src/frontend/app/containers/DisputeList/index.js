import React, {Component} from 'react'
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {Col} from 'react-gosuslugi'
import {FormattedMessage} from 'react-intl'
import {createStructuredSelector} from "reselect"
import messages from './messages'
import {makeSelectDisputes} from "./selectors"
import {loadDisputes} from "./actions"
import SuperList from '../../components/SuperList'

class DisputeList extends Component {
  static propTypes = {
    // from connect
    disputes: PropTypes.object.isRequired
  }

  componentDidMount() {
    this.props.onLoadDisputes('disputes', this.props.match.params.tag)
  }

  componentDidUpdate(prevProps){
    if (this.props.location !== prevProps.location) {
      this.props.onLoadDisputes('disputes', this.props.match.params.tag)
    }
  }

  render() {
    const {disputes, onToggleFavorite} = this.props
    const superDisputes = disputes.get("disputes").toJS()
    return (
      <Col xs={6} sm={8} md={18} lg={18}>
        <div className="disputes">
          <ul className="disputes__list">
            {superDisputes && superDisputes.length >0 ? superDisputes.map(dispute => {
              return (
                <SuperList
                  key={dispute.id}
                  id={dispute.id}
                  mode='disputes'
                  title={dispute.title_short}
                  state={dispute.state}
                  organization={dispute.organization}
                  dispute_started_at={dispute.dispute_started_at}
                  dispute_ended_at={dispute.dispute_ended_at}
                  customer={dispute.customer}
                  object_description={dispute.object_description}
                  remaining={dispute.remaining}
                  tags={dispute.tags}
                  favorite={dispute.favorite}
                  onToggleFavorite={onToggleFavorite}
                />
              )
            }):
            <h3><FormattedMessage {...messages.NoDisputes} /></h3>
            }
          </ul>
        </div>
      </Col>
    )
  }
}

const mapStateToProps = () => createStructuredSelector({
  disputes: makeSelectDisputes()
})

const mapDispatchToProps = (dispatch) => {
  return {
    onLoadDisputes: (type, filter) => {
      dispatch(loadDisputes(type, filter))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(DisputeList)
