import {fromJS, List} from 'immutable'

import {
  ADD_FORM_DISPUTE, TOGGLE_FAVORITE, LOAD_DISPUTES, START, FAIL, SUCCESS, CLEAR, CLEAR_STATUS
} from '../App/constants'

const initialStateDisputes = fromJS({
  disputes: List([]),
  newDispute: {}
})


export function disputesReducer(statusDisputes = initialStateDisputes, action) {
  const {type, payload, error} = action

  switch (type) {
    case TOGGLE_FAVORITE:
      return statusDisputes.update("disputes", list => list.map(item =>
        (item.get("id") === payload.disputeId ?
          item.update("favorite", comment => !comment)
          : item)
      ))

    case ADD_FORM_DISPUTE + START:
      return statusDisputes
        .set('sending', true)
        .set('sent', false)

    case ADD_FORM_DISPUTE:
      return statusDisputes
        .set('sending', false)
        .set('sent', true)
        .set('error', false)
        .set("newDispute", payload)

    case ADD_FORM_DISPUTE + FAIL:
      return statusDisputes
        .set('sending', false)
        .set('sent', false)
        .set('error', error)

    case ADD_FORM_DISPUTE + CLEAR_STATUS:
      return statusDisputes
        .set('sending', undefined)
        .set('sent', undefined)
        .set('error', undefined)

    case CLEAR + ADD_FORM_DISPUTE:
      return statusDisputes.set("newDispute", {})

    case LOAD_DISPUTES + START:
      return statusDisputes.set('loading', true)

    case LOAD_DISPUTES + FAIL:
      return statusDisputes
        .set('loading', false)
        .set('error', error)

    case LOAD_DISPUTES + SUCCESS:
      return statusDisputes
        .set('loading', false)
        .set('loaded', true)
        .set('disputes',  fromJS(payload))

  }
  return statusDisputes
}
