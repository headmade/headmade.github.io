export const DEFAULT_LOCALE = 'ru'
export const CHANGE_LOCALE = 'app/LanguageToggle/CHANGE_LOCALE'

export const ADD_COMMENT = 'ADD_COMMENT'
export const ADD_SERVANT_COMMENT = 'ADD_SERVANT_COMMENT'
export const ADD_FORM_DISPUTE = 'ADD_FORM_DISPUTE'
export const TOGGLE_FAVORITE = 'TOGGLE_FAVORITE'

export const LOAD_DISPUTES = 'LOAD_DISPUTES'
export const LOAD_DISPUTE = 'LOAD_DISPUTE'
export const LOAD_COMMENTS = 'LOAD_COMMENTS'
// export const LOAD_FAVORITE_COMMENTS = 'LOAD_FAVORITE_COMMENTS'
export const LOAD_USER = 'LOAD_USER'

export const START = '_START'
export const SUCCESS = '_SUCCESS'
export const FAIL = '_FAIL'
export const CLEAR = 'CLEAR_'
export const CLEAR_STATUS = '_CLEAR_STATUS'
