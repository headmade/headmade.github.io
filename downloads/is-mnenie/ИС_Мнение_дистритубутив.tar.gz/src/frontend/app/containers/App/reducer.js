import {fromJS} from 'immutable'
import {
  START, FAIL, SUCCESS, LOAD_USER
} from './constants'

const initialStateUser = fromJS({
  user: {}
})

export function userReducer(stateUser = initialStateUser, action) {
  const {type, error, response} = action

  switch (type) {
    case LOAD_USER + START:
      return stateUser.set('loading', true)

    case LOAD_USER + FAIL:
      return stateUser
        .set('loading', false)
        .set('error', error)

    case LOAD_USER + SUCCESS:
      return stateUser
        .set('loading', false)
        .set('loaded', true)
        .set('user', fromJS(response))

  }
  return stateUser
}
