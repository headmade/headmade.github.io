import React from 'react'
import {Switch, Route} from 'react-router-dom'
import {Container} from 'react-gosuslugi'
import Header from '../Header'
import Tags from '../Tags'
import NotFound from '../NotFoundPage/Loadable'
import LoadDisputes from "../DisputeList/Loadable"
import LoadDispute from "../DisputeShow/Loadable"
import LoadDisputeNew from "../DisputeNew/Loadable"
import LoadExpositions from "../ExpositionList/Loadable"
import LoadNotifications from "../NotificationList/Loadable"


class App extends React.Component{
  state = {
    hasError: false
  }

  componentDidCatch(error, info){
    this.setState({ hasError: true })
    console.log(error, info) // eslint-disable-line no-console
  }

  render() {
    if (this.state.hasError) {
      return (
        <div>
          <Container>
            <NotFound problem="error" />
          </Container>
        </div>
      )
    } else {
      return [
        <Header key={1} />,
        <Container key={2} >
          <Tags />
          <Switch>
            <Route exact path="/" component={LoadNotifications} />
            <Route path="/expositions/:id" component={LoadDispute} />
            <Route path="/expositions" component={LoadExpositions} />
            <Route path="/disputes/:id" component={LoadDispute} />
            <Route path="/disputes" component={LoadDisputes} />
            <Route path="/newDispute" component={LoadDisputeNew} />
            <Route path="/tags/:tag" component={LoadDisputes} />
            <Route component={NotFound} />
          </Switch>
        </Container>
      ]
    }
  }
}

export default App
