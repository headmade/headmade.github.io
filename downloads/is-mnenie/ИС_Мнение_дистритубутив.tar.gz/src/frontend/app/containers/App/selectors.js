import {createSelector} from 'reselect'

const selectUser = state => state.get('user')

const makeSelectUser = () => createSelector(selectUser, user => user)

export {
  selectUser,
  makeSelectUser
}
