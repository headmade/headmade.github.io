import React, {PureComponent} from 'react'
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {Col} from 'react-gosuslugi'
import {createStructuredSelector} from "reselect"
import {makeSelectDisputes} from "../DisputeList/selectors"
import {loadDisputes} from "../DisputeList/actions"
import SuperNotificationList from '../../components/SuperList/notification'

class NotificationList extends PureComponent {
  static propTypes = {
    // from connect
    disputes: PropTypes.object.isRequired,
    onLoadDisputes: PropTypes.func.isRequired
  }

  componentDidMount() {
    this.props.onLoadDisputes()
  }

  render() {
    const {disputes} = this.props
    const superDisputes = disputes.get("disputes").toJS()
    return (
      <Col xs={6} sm={8} md={18} lg={18}>
        <div className="disputes">
          <ul className="disputes__list">
            {superDisputes && superDisputes.length > 0 ? superDisputes.map(dispute => {
              return (
                <SuperNotificationList
                  key={dispute.id}
                  dispute={dispute}
                />
              )
            }) : <h3>Сейчас нет оповещений об общественных обсуждениях</h3>}
          </ul>
        </div>
      </Col>
    )
  }
}

const mapStateToProps = () => createStructuredSelector({
  disputes: makeSelectDisputes()
})

const mapDispatchToProps = (dispatch) => {
  return {
    onLoadDisputes: () => {
      dispatch(loadDisputes('notifications'))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(NotificationList)
