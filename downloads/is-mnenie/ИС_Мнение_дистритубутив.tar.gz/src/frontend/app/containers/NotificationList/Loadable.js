import React from 'react'
import Loadable from 'react-loadable'
import {Loader, Col} from 'react-gosuslugi'
import NotFound from '../NotFoundPage'

function Loading(props) {
  if (props.error) {
    return <NotFound problem="error" />
  } else if (props.pastDelay) {
    return (
      <Col xs={6} sm={8} md={18} lg={18}>
        <div className="disputes">
          <Loader />
        </div>
      </Col>
    )
  } else {
    return null
  }
}

const LoadNotifications = Loadable({
  loader: () => import('./index'),
  loading: Loading
})

export const LoadKioskNotification = Loadable({
  loader: () => import('./kiosk'),
  loading: Loading
})

export default LoadNotifications
