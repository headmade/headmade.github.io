import React, {Component} from 'react'
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {Col, Container, BannerLogo} from 'react-gosuslugi'
import {createStructuredSelector} from "reselect"
import {makeSelectDisputes} from "../DisputeList/selectors"
import {loadDisputes} from "../DisputeList/actions"
import SuperNotificationList from '../../components/SuperList/notification'

class NotificationList extends Component {
  static propTypes = {
    // from connect
    disputes: PropTypes.object.isRequired,
    onLoadDisputes: PropTypes.func.isRequired
  }

  state = {dispute: 0}

  componentDidMount() {
    this.props.onLoadDisputes()
    this.interval = this.toggleDispute()
    this.updateDisputes = setInterval(this.props.onLoadDisputes, 1800000)
  }

  componentWillUnmount() {
    clearInterval(this.interval)
    clearInterval(this.updateDisputes)
  }

  toggleDispute(){
    const iteratorFunc = () => {
      this.setState((prevState, props) => {
        const superDisputes = props.disputes.get("disputes").toJS()
        if (superDisputes && prevState.dispute >= superDisputes.length - 1){
          return {dispute: 0}
        }
        return {dispute: prevState.dispute + 1}
      })
    }
    return setInterval(iteratorFunc, 10000)
  }

  render() {
    const {disputes} = this.props
    const superDisputes = disputes.get("disputes").toJS()
    const dispute = superDisputes && superDisputes[this.state.dispute]
    return (
      <div>
        <div className="nav-wrapper nav-wrapper--kiosk">
          <Container>
            <Col xs={6} sm={12} md={24} lg={24}>
              <ul className="nav-list">
                <li className="nav-list__item">
                  <BannerLogo prefix="ИС" suffix="ОО" />
                </li>
                <ul className='nav-list__items'>
                  <li className="nav-list__item nav-list__item--kiosk">
                    Информационный стенд
                  </li>
                  <li className="nav-list__dropdown nav-list__dropdown-user nav-list__dropdown--kiosk">
                    {this.state.dispute+1}/{superDisputes && superDisputes.length}
                  </li>
                </ul>
              </ul>
            </Col>
          </Container>
        </div>
        <Container>
          <Col xs={6} sm={8} md={24} lg={24}>
            <div className="disputes disputes__kiosk">
              <ul className="disputes__list">
                {dispute ?
                  <SuperNotificationList
                    key={dispute.id}
                    dispute={dispute}
                  /> :
                  <h3 className="disputes__item--kiosk">Сейчас нет оповещений об общественных обсуждениях</h3>
                }
              </ul>
            </div>
          </Col>
        </Container>
      </div>
    )
  }
}

const mapStateToProps = () => createStructuredSelector({
  disputes: makeSelectDisputes()
})

const mapDispatchToProps = (dispatch) => {
  return {
    onLoadDisputes: () => {
      dispatch(loadDisputes('notifications'))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(NotificationList)
