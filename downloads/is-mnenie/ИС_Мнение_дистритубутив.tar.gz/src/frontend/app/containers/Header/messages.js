import {defineMessages} from 'react-intl'

export default defineMessages({
  notifications: {
    id: 'app.containers.Header.notifications',
    defaultMessage: 'Оповещения'
  },
  expositions: {
    id: 'app.containers.Header.expositions',
    defaultMessage: 'Экспозиции'
  },
  disputes: {
    id: 'app.containers.Header.disputes',
    defaultMessage: 'Обсуждения'
  }
})
