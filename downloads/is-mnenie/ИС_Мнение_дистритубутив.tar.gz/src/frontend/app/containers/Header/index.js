import React, {Component} from 'react'
import PropTypes from 'prop-types'
import {FormattedMessage} from 'react-intl'
import {connect} from 'react-redux'
import {createStructuredSelector} from "reselect"
import {Container, Col, Hamburger, BannerLogo, ToggleOpen} from 'react-gosuslugi'
import {NavLink, withRouter} from 'react-router-dom'
import {makeSelectUser} from "../App/selectors"
import DropdownUser from '../../components/DropdownUser/index'
import messages from './messages'

export class Header extends Component {
  static propTypes = {
    // from connect
    user: PropTypes.object,
    // from decorator
    isOpen: PropTypes.bool.isRequired,
    toggleOpen: PropTypes.func.isRequired
  }

  render() {
    const {user, toggleOpen, isOpen} = this.props
    const userName = user.get("name")
    const userRole = user.get('type')
    const authPath = user.get('auth_path')
    const logoutPath = user.get('logout_path')
    return (
      <div className="nav-wrapper">
        <Container>
          <Col xs={6} sm={12} md={24} lg={24}>
            <ul className="nav-list">
              <li className="nav-list__item">
                <BannerLogo prefix="ИС" suffix="ОО" />
              </li>
              <ul className={`nav-list__items ${isOpen ? 'nav-list__items_active' : ''}`}>
                <li className="nav-list__item">
                  <NavLink exact activeClassName="nav-list__item_active" to="/">
                    <FormattedMessage {...messages.notifications} />
                  </NavLink>
                </li>
                <li className="nav-list__item">
                  <NavLink activeClassName="nav-list__item_active" to="/expositions">
                    <FormattedMessage {...messages.expositions} />
                  </NavLink>
                </li>
                <li className="nav-list__item">
                  <NavLink activeClassName="nav-list__item_active" to="/disputes">
                    <FormattedMessage {...messages.disputes} />
                  </NavLink>
                </li>
                { userRole? <DropdownUser logoutPath={logoutPath}>
                  {userName}
                </DropdownUser>:
                <li className="nav-list__dropdown nav-list__dropdown-user">
                  <a href={authPath}>Войти</a>
                </li>
                }
              </ul>
              <Hamburger isOpen={isOpen} toggleOpen={toggleOpen} />
            </ul>
          </Col>
        </Container>
      </div>
    )
  }
}

const mapStateToProps = createStructuredSelector({
  user: makeSelectUser()
})

export default withRouter(connect(mapStateToProps)(ToggleOpen(Header)))
