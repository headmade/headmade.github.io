import {CHANGE_LOCALE} from '../App/constants'

export default function changeLocale(languageLocale) {
  return {
    type: CHANGE_LOCALE,
    locale: languageLocale
  }
}
