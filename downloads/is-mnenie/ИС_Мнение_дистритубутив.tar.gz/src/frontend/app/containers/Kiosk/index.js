import React from 'react'
import {Switch, Route} from 'react-router-dom'
import {Container} from 'react-gosuslugi'
import NotFound from '../NotFoundPage/Loadable'
import {LoadKioskNotification} from "../NotificationList/Loadable"

class App extends React.Component{
  state = {
    hasError: false
  }

  componentDidCatch(error, info){
    this.setState({ hasError: true })
    console.log(error, info) // eslint-disable-line no-console
  }

  render() {
    if (this.state.hasError) {
      return (
        <div>
          <Container>
            <NotFound problem="error" />
          </Container>
        </div>
      )
    } else {
      return (
        <Switch>
          <Route exact path="/" component={LoadKioskNotification} />
        </Switch>
      )
    }
  }
}

export default App
