import React, {Component} from 'react'
import {connect} from 'react-redux'
import PropTypes from 'prop-types'
import {FormattedMessage} from 'react-intl'
import {Label} from 'react-gosuslugi'
import {createStructuredSelector} from "reselect"
import {makeSelectUser} from "../App/selectors"
import OffersForm from '../../components/OffersForm'
import DateTime from '../../components/DateTime'
import ServantCommentsForm from '../../components/ServantCommentsForm/index'
import {addServantComment, addComment, loadComments} from './actions'
import {makeSelectComments} from "./selectors"
import Accordion from '../../decorators/Accordion'
import messages from './messages'
import schemas, {prepareParticipantSchema} from "../../components/Form/schemas/replics"
import prepareSchema from "../../components/Form/prepare_schema"
import ShowForm from '../../components/Form/show_form'
import "./Comments.sass"
import {ADD_SERVANT_COMMENT, CLEAR_STATUS} from "../App/constants"

class Comments extends Component {
  static propTypes = {
    disputeId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    mode: PropTypes.string,
    dispute: PropTypes.object,
    //from connect
    comments: PropTypes.object,
    user: PropTypes.object.isRequired,
    onAddComment: PropTypes.func.isRequired,
    onAddServantComment: PropTypes.func,
    clearServantFormStatus: PropTypes.func,
    onLoadComments: PropTypes.func.isRequired,
    // from decorator
    openItemId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    toggleOpenItem: PropTypes.func
  }

  componentDidMount() {
    this.props.onLoadComments(this.props.mode, this.props.disputeId)
  }

  getOffersForm = (userType, formSent, onAddComment, dispute, mode, authPath, formSending, formError) => {
    if(userType === "user" && !formSent){
      return <OffersForm onAddComment={onAddComment} dispute={dispute} mode={mode} formSending={formSending} formError={formError} />
    } else if(!userType) {
      return (
        <div>
          <p>Для того, чтобы задать вопрос или внести замечание или предложение, необходимо <a href={authPath}>авторизоваться</a> с помощью Вашей учетной записи в Единой системе идентификации и аутентификации (ЕСИА)*.</p>
        </div>
      )
    } else if(userType === "user" && formSent) {
      return (
        <Label bsStyle='success'>
          <span>Ваше сообщение отправлено</span>
        </Label>
      )
    }
    return null
  }

  getServantForm = (openItemId, commentId, formSent, formSending, onAddComment,commentType, disputeId, formError, errorMessage) => {
    if(openItemId === commentId) {
      return <ServantCommentsForm clearServantFormStatus={this.props.clearServantFormStatus} formSent={formSent} onAddComment={onAddComment} type={commentType} commentId={commentId} disputeId={disputeId} formSending={formSending} formError={formError} errorMessage={errorMessage} />
    }
    return null
  }

  getServantComment = (decision) => {
    return (
      <span key={decision.created_at} className="servantComment">
        <span className="servantComment__title">
          <span><FormattedMessage {...messages.DisputeOrganizer} /></span> <span className="comment__date"><DateTime>{decision.created_at}</DateTime></span>
        </span>
        <span className="servantComment__text">{decision.text}</span>
      </span>
    )
  }

  getStatus = (state="validating", mode) => {
    let replic = mode === "disputes" ? "Замечание/предложение" : mode === "expositions" ? "Вопрос" : ""
    replic = ""

    if (state === "validating") {
      return <span className={`comment__state comment__state--${state}`}><FormattedMessage {...messages.Validating} /></span>
    }
    if (state === "accepted") {
      return <span className={`comment__state comment__state--${state}`}>{replic} <FormattedMessage {...messages.Accepted} /></span>
    }
    if (state === "answered") {
      return <span className={`comment__state comment__state--${state}`}>{replic} <FormattedMessage {...messages.Answered} /></span>
    }
    if (state === "rejected") {
      return <span className={`comment__state comment__state--${state}`}>{replic} <FormattedMessage {...messages.Rejected} /></span>
    }
    return null
  }

  servantClick = (id, userType, ev) => {
    ev.stopPropagation()
    ev.preventDefault()
    userType === "servant" ? this.props.toggleOpenItem(id) : null
  }

  servantData(data, mode, dispute){
    const participantSchema = prepareParticipantSchema(schemas['replic'][mode], dispute.participants)
    return <ShowForm className="xsmall" formData={data} schema={prepareSchema(participantSchema)} />
  }

  render() {
    const {dispute, disputeId, user, onAddComment, onAddServantComment, openItemId, mode} = this.props
    const commentsMap = this.props.comments
    const userType = user.get("type")
    const authPath = user.get("auth_path")
    const comments = commentsMap.get('comments').toJS()
    const formSent = commentsMap.get('sent')
    const formSending = commentsMap.get('sending')
    const formError = commentsMap.get('error')
    const errorMessage = commentsMap.get('errorMessage')
    let typeComment
    if(mode === "expositions"){
      typeComment = "question"
    } else {
      typeComment = "suggestion"
    }
    return [
      <section key={1} className="comments">
        <ul className="comments__list">
          {comments && comments.map(comment => {
            if(comment.dispute_id === disputeId && comment.type === typeComment){
              return (
                <li
                  key={comment.id}
                  className={`comments__item ${comment.type==="question"?"comments__item--question":null} comments__item--${comment.state}`}
                >
                  <p className="comment__wrap">
                    <span className="comment__header">
                      {/*<span className="comment__user">{comment.user}</span> - */}<span className="comment__user"><FormattedMessage {...messages.Visitor} />-{comment.user_id}</span>
                      {this.getStatus(comment.state, mode)}
                      <span className="comment__date">
                        <DateTime>{comment.updated_at}</DateTime>
                      </span>
                    </span>
                    <span
                      className={`comments__text ${userType === "servant"?"comments__text--servant":null}`}
                      onClick={(ev) => this.servantClick(comment.id, userType, ev)}
                    >
                      {comment.text}
                    </span>
                    {comment.decisions && comment.decisions.map(decision=>this.getServantComment(decision))}
                  </p>
                  {comment.data && this.servantData(comment.data, mode, dispute)}
                  {this.getServantForm(openItemId, comment.id, formSent, formSending, onAddServantComment, comment.type, disputeId, formError, errorMessage)}
                </li>
              )
            }
          })}
        </ul>
        {this.getOffersForm(userType, formSent, onAddComment, dispute, mode, authPath, formSending, formError)}
      </section>,
      <div key={2}>
        {!userType &&
          <p style={{marginTop: "20px"}}>
            — * в соответствии с
            <a href="http://government.ru/docs/3242/"> Постановлением Правительства Российской Федерации от 10 июля 2013
              г. No 584 «Об использовании федеральной государственной информационной системы «Единая система идентификации
              и аутентификации в инфраструктуре, обеспечивающей информационно-технологическое взаимодействие
              информационных систем, используемых для предоставления государственных и муниципальных услуг в электронной
              форме».</a>
          </p>
        }
      </div>
    ]
  }
}

const mapStateToProps = (_, ownProps) => createStructuredSelector({
  comments: makeSelectComments(ownProps.disputeId),
  user: makeSelectUser()
})

const mapDispatchToProps = (dispatch) => {
  return {
    clearServantFormStatus: () => {
      dispatch({type: ADD_SERVANT_COMMENT + CLEAR_STATUS})
    },
    onAddComment: (comment, mode, disputeId) => {
      dispatch(addComment(comment, mode, disputeId))
    },
    onAddServantComment: (comment, disputeId, commentId) => {
      dispatch(addServantComment(comment, disputeId, commentId))
    },
    onLoadComments: (mode, disputeId) => {
      dispatch(loadComments(mode, disputeId))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Accordion(Comments))
