import {RSAA} from 'redux-api-middleware'
import {ADD_COMMENT, ADD_SERVANT_COMMENT, LOAD_COMMENTS, START, FAIL, SUCCESS} from '../App/constants'   // LOAD_FAVORITE_COMMENTS,

export function loadComments(mode, disputeId) {
  return {
    [RSAA]: {
      endpoint: `/api/${mode}/${disputeId}/replics`,
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      types: [
        LOAD_COMMENTS + START,
        LOAD_COMMENTS + SUCCESS,
        LOAD_COMMENTS + FAIL
      ]
    }
  }
}

// export function loadFavoriteComments() {
//   return {
//     [RSAA]: {
//       endpoint: `/api/favoriteComments.json`,
//       method: 'GET',
//       types: [LOAD_FAVORITE_COMMENTS]
//     }
//   }
// }

export function addComment(comment, mode, disputeId) {
  return {
    [RSAA]: {
      endpoint: `/api/user/${mode}/${disputeId}/replics`,
      method: 'POST',
      types: [ADD_COMMENT+START, ADD_COMMENT, ADD_COMMENT+FAIL],
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({replic: {data: comment}})
    }
  }
}

export function addServantComment(comment, disputeId, commentId) {
  return {
    [RSAA]: {
      endpoint: `/api/servant/disputes/${disputeId}/replics/${commentId}/decisions`,
      method: 'POST',
      types: [ADD_SERVANT_COMMENT+START, ADD_SERVANT_COMMENT, ADD_SERVANT_COMMENT+FAIL],
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({decision: {data: comment}})
    }
  }
}

