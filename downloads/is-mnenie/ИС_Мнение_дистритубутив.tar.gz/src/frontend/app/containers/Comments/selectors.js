import {createSelector} from 'reselect'

const selectComments = (state) => state.get('comments')

const makeSelectComments = () => createSelector(selectComments, (comments) => comments)

export {
  selectComments,
  makeSelectComments
}
