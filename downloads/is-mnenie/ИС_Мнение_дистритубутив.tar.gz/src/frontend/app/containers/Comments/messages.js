import {defineMessages} from 'react-intl'

export default defineMessages({
  DisputeOrganizer: {
    id: 'app.containers.Comments.DisputeOrganizer',
    defaultMessage: 'Организатор обсуждения:'
  },
  Validating: {
    id: 'app.containers.Comments.Validating',
    defaultMessage: 'Проверяется статус участника общественных обсуждений'
  },
  Accepted: {
    id: 'app.containers.Comments.Accepted',
    defaultMessage: 'принято на рассмотрение'
  },
  Answered: {
    id: 'app.containers.Comments.Answered',
    defaultMessage: 'рассмотрено'
  },
  Rejected: {
    id: 'app.containers.Comments.Rejected',
    defaultMessage: 'не принят'
  },
  Visitor: {
    id: 'app.containers.Comments.Visitor',
    defaultMessage: 'Посетитель'
  }
})
