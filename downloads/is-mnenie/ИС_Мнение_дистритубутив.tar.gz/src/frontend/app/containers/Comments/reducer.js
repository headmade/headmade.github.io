import {fromJS} from 'immutable'
import {ADD_COMMENT, ADD_SERVANT_COMMENT, FAIL, LOAD_COMMENTS, START, SUCCESS, CLEAR_STATUS} from "../App/constants"

const initialStateComments = fromJS({
  comments: []
})

export function commentsReducer(stateComments = initialStateComments, action) {
  const {type, payload, error} = action

  switch (type) {
    case ADD_SERVANT_COMMENT + START:
      return stateComments
        .set('sending', true)
        .set('sent', false)
        .set('error', false)
        .set('errorMessage', false)

    case ADD_SERVANT_COMMENT:
      return stateComments
        .set('sending', false)
        .set('sent', true)
        .set('error', false)
        .set('errorMessage', false)
        .updateIn(["comments"], list => list.map(item =>{
          return (item.get("id") === payload.replic_id ? item.set("decisions", item.get('decisions').concat(payload)) : item)
        }))

    case ADD_SERVANT_COMMENT + FAIL:
      return stateComments
        .set('sending', false)
        .set('sent', false)
        .set('error', error)
        .set('errorMessage', payload)

    case ADD_SERVANT_COMMENT + CLEAR_STATUS:
      return stateComments
        .set('sent', undefined)
        .set('sending', undefined)
        .set('error', undefined)
        .set('errorMessage', undefined)

    case ADD_COMMENT + START:
      return stateComments
        .set('sending', true)
        .set('sent', false)
        .set('error', false)

    case ADD_COMMENT:
        return stateComments
          .set('sending', false)
          .set('sent', true)
          .set('error', false)
          .updateIn(["comments"], list => list.concat(payload))

    case ADD_COMMENT + FAIL:
      return stateComments
        .set('sending', false)
        .set('sent', false)
        .set('error', error)

    case ADD_COMMENT + CLEAR_STATUS:
      return stateComments
        .set('sent', undefined)
        .set('sending', undefined)
        .set('error', undefined)

    case LOAD_COMMENTS + START:
      return stateComments
        .set('loaded', false)
        .set('loading', true)
        .set('error', false)

    case LOAD_COMMENTS + SUCCESS:
      return stateComments
        .set('loading', false)
        .set('loaded', true)
        .set('error', false)
        .update('comments',  list => list.merge(fromJS(payload)))

    case LOAD_COMMENTS + FAIL:
      return stateComments
        .set('loaded', false)
        .set('loading', false)
        .set('error', error)

  }
  return stateComments
}

