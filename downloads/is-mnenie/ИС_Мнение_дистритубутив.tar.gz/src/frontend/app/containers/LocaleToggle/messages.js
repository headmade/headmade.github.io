import { defineMessages } from 'react-intl'

export default defineMessages({
  en: {
    id: 'app.containers.LocaleToggle.en',
    defaultMessage: 'en'
  },
  ru: {
    id: 'app.containers.LocaleToggle.ru',
    defaultMessage: 'ru'
  }
})
