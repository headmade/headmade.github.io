import { defineMessages } from 'react-intl'

export default defineMessages({
  addDispute: {
    id: 'app.containers.Tags.addDispute',
    defaultMessage: 'Добавить обсуждение'
  },
  favorite: {
    id: 'app.containers.Tags.favorite',
    defaultMessage: 'Избранное'
  },
  genplan: {
    id: 'app.containers.Tags.genplan',
    defaultMessage: 'Генплан'
  },
  pzz: {
    id: 'app.containers.Tags.pzz',
    defaultMessage: 'ПЗЗ'
  },
  deviation: {
    id: 'app.containers.Tags.deviation',
    defaultMessage: 'Разрешение на отклонение'
  },
  urvi: {
    id: 'app.containers.Tags.urvi',
    defaultMessage: 'Разрешение на УРВИ'
  },
  planning: {
    id: 'app.containers.Tags.planning',
    defaultMessage: 'Проект планировки'
  },
  boundary: {
    id: 'app.containers.Tags.boundary',
    defaultMessage: 'Проект межевания'
  }
})
