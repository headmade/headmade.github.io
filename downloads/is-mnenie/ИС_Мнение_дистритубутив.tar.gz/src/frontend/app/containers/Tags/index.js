import React from 'react'
import {Link} from 'react-router-dom'
import PropTypes from 'prop-types'
import {createStructuredSelector} from "reselect"
import {connect} from "react-redux"
import { FormattedMessage } from 'react-intl'
import {Col, Button} from 'react-gosuslugi'
//import LocaleToggle from 'containers/LocaleToggle'

import './Tags.sass'
import {makeSelectUser} from "../../containers/App/selectors"
import messages from "./messages"

const tags = [
  {key: 'genplan', name: <FormattedMessage {...messages.genplan} />},
  {key: 'pzz', name: <FormattedMessage {...messages.pzz} />},
  {key: 'deviation', name: <FormattedMessage {...messages.deviation} />},
  {key: 'urvi', name: <FormattedMessage {...messages.urvi} />},
  {key: 'planning', name: <FormattedMessage {...messages.planning} />},
  {key: 'boundary', name: <FormattedMessage {...messages.boundary} />}
]

function Tags({user}){
  const userType = user.get("type")
  return (
    <Col xs={6} sm={4} md={6} lg={6} >
      <div className="tags">
        <ul className="tags__list">
          {tags.map(tag=> { return (
            <li key={tag.key} className="tags__item">
              <Link to={`/tags/${tag.key}`} className="tags__link">
                <p className="tags__name">{tag.name}</p>
              </Link>
            </li>
          )})}
          <li className="tags__item">
            <Link to={`/tags/favorites`} className="tags__link">
              <p className="tags__name"><FormattedMessage {...messages.favorite} /></p>
            </Link>
          </li>
        </ul>
        {userType === "servant" ?
          <Link to={`/newDispute`} className="tags__button">
            <Button bsStyle="primary" >
              {/*<div className="button__loading" />*/}
              <FormattedMessage {...messages.addDispute} />
            </Button>
          </Link>
          : null
        }
        {
        //Добавить после добавления языка
        //<div className="tags__coop"><LocaleToggle /><span>DISPUTE KAZAN © 2018</span></div>
        }
        <div className="tags__coop"><span>Информационная система «Общественные обсуждения» © 2018</span></div>
      </div>
    </Col>
  )
}

Tags.propTypes = {
  user: PropTypes.object
}

const mapStateToProps = createStructuredSelector({
  user: makeSelectUser()
})

export default connect(mapStateToProps)(Tags)
