import React from 'react'

const DataShow = ({data}) =>{
  return <pre>{JSON.stringify(data, null, 2)}</pre>
}

export default DataShow
