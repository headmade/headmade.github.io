import React from 'react'
import PropTypes from "prop-types"

const StatusShow = ({sending, sent, error}) => {
  if(sending){
    return <div className="button__loading" />
  }else if(sent){
    return <div className="button__success" />
  }else if(error){
    return <div className="button__error" />
  }
  return null
}

StatusShow.propTypes = {
  sending: PropTypes.bool,
  sent: PropTypes.bool,
  error: PropTypes.bool
}

export default StatusShow
