import React from 'react'
import PropTypes from 'prop-types'
import {FormattedMessage} from 'react-intl'
import messages from './messages'
import Date from '../Date'
// import Favorites from '../../components/Favorites/index'

const SuperDisputeShow = ({dispute, userRole}) => {
  const {
    id,
    title_full,
    object_description,
    dispute_started_at,
    dispute_ended_at,
    organization
    // tags,
    // path,
    // favorite,
    // mode
  } = dispute
  return (
    <ul className="dispute">
      <li className="disputes__item">
        <div className="disputes__header">
          <h4 className="disputes__title">{title_full}</h4>
        </div>
        <p className="disputes__text">{object_description}</p>
        <p><FormattedMessage {...messages.DisputeOrganizer} />: {organization}</p>
        <p>
          <FormattedMessage {...messages.StartDateOfDispute} />: <Date>{dispute_started_at}</Date>
        </p>
        <p>
          <FormattedMessage {...messages.EndDateOfDispute} />: <Date>{dispute_ended_at}</Date>
        </p>
        {userRole !== "servant" ?
          <p>
            <a href={`/expositions/${id}`}><FormattedMessage {...messages.ViewProject} /></a>
          </p> : null
        }
        {/*<p className="disputes__tags">{tags}</p>*/}
        {/*<Favorites path={path} disputeId={id} isFavorite={favorite} mode={mode} />*/}
      </li>
    </ul>
  )
}

SuperDisputeShow.propTypes = {
  userRole: PropTypes.string,
  dispute: PropTypes.object
}

export default SuperDisputeShow
