import {defineMessages} from 'react-intl'

export default defineMessages({
  DisputeOrganizer: {
    id: 'app.components.SuperShow.dispute.DisputesOrganizer',
    defaultMessage: 'Организатор обсуждения'
  },
  StartDateOfDispute: {
    id: 'app.components.SuperShow.dispute.StartDateOfDispute',
    defaultMessage: 'Дата начала обсуждения'
  },
  EndDateOfDispute: {
    id: 'app.components.SuperShow.dispute.EndDateOfDispute',
    defaultMessage: 'Дата окончания обсуждения'
  },
  ViewProject: {
    id: 'app.components.SuperShow.dispute.ViewProject',
    defaultMessage: 'Посмотреть проект'
  },
  StartDateOfExposition: {
    id: 'app.components.SuperShow.exposition.StartDateOfExposition',
    defaultMessage: 'Дата открытия экспозиции'
  },
  EndDateOfExposition: {
    id: 'app.components.SuperShow.exposition.EndDateOfExposition',
    defaultMessage: 'Дата закрытия экспозиции'
  },
  Download: {
    id: 'app.components.SuperShow.exposition.Download',
    defaultMessage: 'Скачать'
  },
  LeaveACommentOrSuggestion: {
    id: 'app.components.SuperShow.exposition.LeaveACommentOrSuggestion',
    defaultMessage: 'Оставить замечание или предложение'
  }
})
