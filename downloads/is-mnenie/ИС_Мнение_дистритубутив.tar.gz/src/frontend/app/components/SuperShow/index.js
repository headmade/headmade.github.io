import React from 'react'
import PropTypes from "prop-types"
import {Icon} from 'react-gosuslugi'
import {FormattedMessage} from 'react-intl'
import messages from './messages'
import Date from '../Date'
import SuperDisputeShow from './dispute'
import SuperExpositionShow from './exposition'
// import Favorites from '../Favorites'
//import ShowForm from '../../components/Form/show_form'
//import defaultSchema from '../../components/Form/default_schema'

const showComponents = {
  disputes: SuperDisputeShow,
  expositions: SuperExpositionShow
}

export const mapToComponents = (type)=>{
  return showComponents[type] || SuperShow
}

const SuperShow = ({dispute, userRole}) => {
  const {
    id,
    title_full,
    object_description,
    dispute_started_at,
    dispute_ended_at,
    tags,
    // mode,
    // onToggleFavorite,
    // path,
    // favorite,
    organization,
    //customer,
    data
  } = dispute
  const files = data && data.attachments || []
  if (data){
    delete data.attachments
  }

  return (
    <ul className="dispute">
      <li className="disputes__item">
        <div className="disputes__header">
          <h4 className="disputes__title">{title_full}</h4>
          {/*<p className="disputes__date">{state}</p>*/}
        </div>
        <p className="disputes__text">{object_description}</p>
        <p><FormattedMessage {...messages.DisputeOrganizer} />: {organization}</p>
        <p>
          <FormattedMessage {...messages.StartDateOfDispute} />: <Date>{dispute_started_at}</Date>
        </p>
        <p>
          <FormattedMessage {...messages.EndDateOfDispute} />: <Date>{dispute_ended_at}</Date>
        </p>
        {userRole !== "servant" ?
          <p>
            <a href={`/expositions/${id}`}><FormattedMessage {...messages.ViewProject} /></a>
          </p> : null
        }
        {/*<ProgressBar remaining={1200} />*/}
        {/*<ShowForm formData={schemaData} schema={schema} className='xsmall' />*/}
        <p className="disputes__tags">{tags}</p>
        <ul className="disputes__files">
          <li className='download-files-wrapper download-files-wrapper-vertical'>
            {files && files.map((file) => {
              return (
                <a key={file.id} href={file.url} target="_blank" className={`download-files__item download-files__item-${file.size}`}>
                  <div className="item__img">
                    <Icon type={file.format || 'all'} />
                  </div>
                  <div className="item__text">
                    <p className="item__name">{file.title}</p>
                    <p className="item__download"><FormattedMessage {...messages.Download} /></p>
                  </div>
                </a>
              )})}
          </li>
        </ul>
        {/*<Favorites onToggleFavorite={onToggleFavorite} path={path} disputeId={id} isFavorite={favorite} mode={mode} />*/}
      </li>
    </ul>
  )
}

SuperShow.propTypes = {
  userRole: PropTypes.string,
  dispute: PropTypes.object
}

export default SuperShow
