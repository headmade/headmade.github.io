import React from 'react'
import moment from 'moment'
import {FormattedMessage} from 'react-intl'
import messages from './messages'
import Date from '../Date'

const SuperNotificationList = ({dispute}) => {
  let dispute_started_at = moment(dispute.dispute_started_at)
  let dispute_ended_at = moment(dispute.dispute_ended_at)
  return (
    <li className="disputes__item">
      <div className="disputes__header">
        <span className="disputes__link">
          <h4 className="disputes__title"> Оповещение о начале общественных обсуждений по проекту {dispute.title_full}</h4>
        </span>
        <span><FormattedMessage {...messages.PublishedOn} />: <Date>{dispute.created_at}</Date></span>
      </div>
      <div>
        <p>
          В соответствии с постановлением Мэра города Казани от <Date>{dispute.notification_published_at}</Date> №{dispute.notification.major_decree_number}
          «О назначении общественных обсуждений <b>{dispute.title_full}»</b> <span className="notification_accent"> с <Date>{dispute.dispute_started_at}</Date> по <Date >{dispute.dispute_ended_at}</Date></span>
          в информационной системе «Общественные обсуждения» по адресу <b>https://dispute.kzn.ru</b> (далее – ИС «Общественные обсуждения») проводятся общественные обсуждения по проекту {dispute.title_full}.
        </p>
        <ul className="notification_list">
          <li className="notification_list--item_caption">Перечень информационных материалов:</li>
          {dispute.attachments.map((attachment, index) => {
            return(
              <li key={index}>{attachment.description}</li> //eslint-disable-line
            )
          })}
        </ul>
        <p>
          Экспозиция проекта будет открыта в ИС «Общественные обсуждения» по адресу: <b>https://dispute.kzn.ru/expositions/{dispute.id}</b> <span className="notification_accent"> с <Date>{dispute.dispute_started_at}</Date> года в течении {1+dispute_ended_at.diff(dispute_started_at, 'days')} дней</span>.
        </p>
        <p>
          Посещение ИС «Общественные обсуждения» в здании организатора общественных обсуждений возможно
          по адресу: <b>{dispute.system_location}</b>,
          режим посещения: <b>{dispute.system_location_schedule}</b>.
        </p>
        <ul className="notification_list">
          <li className="notification_list--item_caption">
            Участники общественных обсуждений в период с <Date>{dispute.dispute_started_at}</Date> до <Date>{dispute.dispute_ended_at}</Date>
            имеют право внести предложения и замечания, касающиеся проекта, подлежащего рассмотрению на общественных обсуждениях:
          </li>
          <li>
            посредством ИС «Общественные обсуждения» по адресу: https://dispute.kzn.ru/disputes/{dispute.id};
          </li>
          <li>
            в письменной форме организатору общественных обсуждений по адресу: {dispute.organization_address};
          </li>
          <li>
            посредством записи в книге (журнале) учёта посетителей экспозиции проекта, подлежащего рассмотрению на общественных обсуждениях
            по адресу: <b>{dispute.participant_registration_location}</b>.
          </li>
        </ul>
      </div>
    </li>
  )
}

//SuperList.propTypes = {
  //id: PropTypes.string,
  //title: PropTypes.string,
  //status: PropTypes.string,
  //published_at: PropTypes.string,
  //object_description: PropTypes.string,
  //remaining: PropTypes.number,
  //tags: PropTypes.string,
  //favorite: PropTypes.bool,
  //onToggleFavorite: PropTypes.func
//}

export default SuperNotificationList
