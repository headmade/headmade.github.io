import React from 'react'
import PropTypes from "prop-types"
import {Link} from 'react-router-dom'
import {FormattedMessage} from 'react-intl'
import messages from './messages'
import Date from '../Date'
// import ProgressBar from '../../components/ProgressBar/index'
//import Favorites from '../Favorites'


const SuperList = ({
  id,
  mode,
  title,
  state,
  organization,
  dispute_started_at,
  dispute_ended_at
  //object_description,
  //customer,
  //remaining,
  //favorite,
  //onToggleFavorite,
  // tags
}) => {
  return (
    <li className="disputes__item">
      <div className="disputes__header">
        <Link to={`/${mode}/${id}`} className="disputes__link">
          <h4 className="disputes__title">{title}</h4>
        </Link>
        <div className="disputes__date">
          <span>{' '||state}</span>
          <span><FormattedMessage {...messages.TimeSpending} />: <Date>{dispute_started_at}</Date> - <Date>{dispute_ended_at}</Date></span>
        </div>
      </div>
      <p><FormattedMessage {...messages.Organizer} />: {organization}</p>
      {/*<p className="disputes__text">{object_description}</p>*/}
      <Link to={`/${mode}/${id}`} className="disputes__link">
        <span className="disputes__learn-more">
          <FormattedMessage {...messages.LearnMore} />
        </span>
      </Link>
      {/*<ProgressBar remaining={remaining} />*/}
      {/*<p className="disputes__tags">{tags}</p>*/}
      {/*<Favorites disputeId={id} onToggleFavorite={onToggleFavorite} isFavorite={favorite} mode={mode} />*/}
    </li>
  )
}

SuperList.propTypes = {
  id: PropTypes.number,
  mode: PropTypes.string,
  title: PropTypes.string,
  state: PropTypes.string,
  organization: PropTypes.string,
  dispute_started_at: PropTypes.string,
  dispute_ended_at: PropTypes.string
  //favorite: PropTypes.bool,
  //onToggleFavorite: PropTypes.func,
  //remaining: PropTypes.string,
  //object_description: PropTypes.string,
  //customer: PropTypes.string,
  // tags: PropTypes.string
}

export default SuperList
