import {defineMessages} from 'react-intl'

export default defineMessages({
  LearnMore: {
    id: 'app.components.SuperList.LearnMore',
    defaultMessage: 'Подробнее...'
  },
  Organizer: {
    id: 'app.components.SuperList.Organizer',
    defaultMessage: 'Организатор'
  },
  TimeSpending: {
    id: 'app.components.SuperList.TimeSpending',
    defaultMessage: 'Время проведения'
  },
  PublishedOn: {
    id: 'app.components.SuperList.notification.PublishedOn',
    defaultMessage: 'Опубликовано'
  }
})
