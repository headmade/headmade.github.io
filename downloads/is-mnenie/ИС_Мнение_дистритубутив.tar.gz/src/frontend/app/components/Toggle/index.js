import React from 'react'
import PropTypes from 'prop-types'
import { injectIntl, intlShape } from 'react-intl'

function Toggle({values, intl, messages, value, onToggle}) {
  let content = (<option>--</option>)
  // If we have items, render them
  if (values) {
    content = values.map((value) => {
      const message = messages[value]
      return(
        <option key={value} value={value}>
          {message ? intl.formatMessage(message) : value}
        </option>
      )
    })
  }

  return (
    <select style={{lineHeight: "1em", height: "20px", marginRight: "10px"}} value={value} onChange={onToggle}>
      {content}
    </select>
  )
}

Toggle.propTypes = {
  onToggle: PropTypes.func,
  values: PropTypes.array,
  value: PropTypes.string,
  messages: PropTypes.object,
  intl: intlShape.isRequired
}

export default injectIntl(Toggle)
