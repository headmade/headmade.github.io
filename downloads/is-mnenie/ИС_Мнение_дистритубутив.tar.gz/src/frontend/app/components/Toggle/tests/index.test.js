import React from 'react'
import renderer from 'react-test-renderer'
import { IntlProvider, intlShape } from 'react-intl'

import Toggle from '../index'

test('Toggle with params', () => {
  const component = renderer.create(
    <IntlProvider locale="en">
      <Toggle intlShape={intlShape} />
    </IntlProvider>
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})