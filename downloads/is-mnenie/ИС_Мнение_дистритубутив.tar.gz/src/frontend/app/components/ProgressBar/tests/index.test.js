import React from 'react'
import renderer from 'react-test-renderer'

import ProgressBar from '../index'

test('ProgressBar with params', () => {
  const component = renderer.create(
    <ProgressBar remaining={5000} />
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})