import React, {Component} from 'react'
import PropTypes from 'prop-types'
import moment from 'moment'

import './ProgressBar.sass'

class ProgressBar extends Component {
  static propTypes = {
    interval: PropTypes.number, // msec
    remaining: PropTypes.number, // msec
    afterTick: PropTypes.func, // callback after each ticks
    afterComplete: PropTypes.func // callback after remaining <= 0
  }

  static defaultProps = {
    interval: 1000,
    afterTick: null,
    afterComplete: null,
    children: null
  }

  constructor(props, ...args) {
    super(props, ...args)
    this.timerId = null
    this.prevTime = null
    this.state = { remaining: props.remaining }
  }

  componentDidMount() {
    this.timerId = setInterval(this.handleTick.bind(this), this.props.interval)
    this.prevTime = moment()
  }

  componentWillUnmount() {
    this.clearTimer()
  }

  clearTimer() {
    clearInterval(this.timerId)
    this.timerId = null
    this.prevTime = null
  }

  handleTick() {
    const currentTime = moment()
    const elapsed = currentTime - this.prevTime
    const nextRemaining = this.state.remaining - elapsed
    if (nextRemaining <= 0) {
      if (this.props.afterComplete !== null) {
        this.props.afterComplete()
      }
      this.clearTimer()
      this.setState({ remaining: 0 })
    } else {
      if (this.props.afterTick !== null) {
        this.props.afterTick(nextRemaining)
      }
      this.prevTime = currentTime
      this.setState({ remaining: nextRemaining })
    }
  }

  render() {
    const {remaining} = this.state
    const minutes = moment(remaining).format('mm')
    // const seconds = moment(remaining).format('ss')
    const total = 15*60000
    const w = 100 - ((total - remaining) / total) * 100
    const label = minutes > 2 ? "info" : "warning"
    return (
      <div className="progress">
        { remaining ? (
          <div className={"progress-bar progress-bar-"+label} role="progressbar" aria-valuenow={remaining} aria-valuemin="0" aria-valuemax={total} style={{width: w+"%"}}>
            {/*<span className="progress-bar__times">{minutes}:{seconds}</span>*/}
            <span className="progress-bar__times">12 дней</span>
          </div>
        ):(
          <div className="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style={{width: "100%"}}>
            Обсуждение закончилось
          </div>
        )}
      </div>
    )
  }
}

export default ProgressBar
