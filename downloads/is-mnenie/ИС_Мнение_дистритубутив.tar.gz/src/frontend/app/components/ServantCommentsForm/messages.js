import {defineMessages} from 'react-intl'

export default defineMessages({
  Send: {
    id: 'app.components.ServantCommentsForm.Send',
    defaultMessage: 'Отправить'
  }
})
