import React, {Component} from 'react'
import {Button} from 'react-gosuslugi'
 import {fromJS} from "immutable"
import PropTypes from "prop-types"
import {FormattedMessage} from 'react-intl'
import messages from "./messages"
import StatusShow from "../../components/StatusShow"
import prepareSchema from "../Form/prepare_schema"
import UIForm from "../Form/ui_form"
import schemas, {decision_ui_schema} from "../../components/Form/schemas/replics"

export default class ServantCommentsForm extends Component {
  static propTypes = {
    commentId: PropTypes.number.isRequired,
    disputeId: PropTypes.number.isRequired,
    type: PropTypes.string.isRequired,
    formError: PropTypes.bool,
    formSent: PropTypes.bool,
    formSending: PropTypes.bool,
    onAddComment: PropTypes.func.isRequired,
    clearServantFormStatus: PropTypes.func.isRequired
  }

  componentDidMount(){
    this.props.clearServantFormStatus()
  }

  onSubmit = (event) => {
    const {commentId, disputeId, onAddComment} = this.props
    const formData = event.formData
    onAddComment(fromJS(formData), disputeId, commentId)
  }

  render() {
    const {formSending, formError, formSent, type, errorMessage} = this.props
    const decision_schema = schemas['decision'][type]
    return (
      <div>
        <UIForm onSubmit={this.onSubmit} className="comments__editor" schema={prepareSchema(decision_schema)} uiSchema={decision_ui_schema}>
          {errorMessage && <p style={{color: "red"}}>{errorMessage.message}</p>}
          <div className="buttonWrapper">
            <Button bsStyle="success"  type="submit" disabled={formSending}>
              <StatusShow sending={formSending} sent={formSent} error={formError} />
              <FormattedMessage {...messages.Send} />
            </Button>
          </div>
        </UIForm>
      </div>
    )
  }
}
