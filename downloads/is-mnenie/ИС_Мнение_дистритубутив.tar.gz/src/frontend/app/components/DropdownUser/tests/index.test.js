import React from 'react'
import renderer from 'react-test-renderer'
import {shallow} from 'enzyme'
import {IntlProvider} from 'react-intl'

import DropdownUser from '../index'

test('DropdownUser with params', () => {
  const component = renderer.create(
    <IntlProvider locale="en">
      <DropdownUser handleClick={()=>{}} isOpen={false}>
        test
      </DropdownUser>
    </IntlProvider>
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})

describe('<DropdownUser />', () => {
  it('should render the page message', () => {
    const text = 'test'
    const renderedComponent = shallow(
      <DropdownUser >
        {text}
      </DropdownUser>
    )
    expect(renderedComponent.contains(text)).toEqual(true)
  })
})
