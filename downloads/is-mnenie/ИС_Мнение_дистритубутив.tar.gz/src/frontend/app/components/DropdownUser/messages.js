import {defineMessages} from 'react-intl'

export default defineMessages({
  exit: {
    id: 'app.components.DropdownUser.exit',
    defaultMessage: 'Выход'
  }
})
