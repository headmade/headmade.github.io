import React from 'react'
import PropTypes from 'prop-types'
import {FormattedMessage} from 'react-intl'
import {ToggleOpen} from 'react-gosuslugi'
import messages from './messages'

const DropdownUser = ({isOpen, children, handleClick, logoutPath}) => {
  return (
    <li className="nav-list__dropdown nav-list__dropdown-user">
      <a
        className={`nav-list__dropdown-caption nav-list__dropdown-caption--user ${isOpen ? 'active' : ''}`}
        onClick={handleClick}
      >
        {children}
      </a>
      {isOpen &&
      <ul className="dropdown">
        <div className="overlay" onClick={handleClick} />
        <li className="dropdown__row-top">
          <a className="dropdown__row-top-user--exit" href={logoutPath}><FormattedMessage {...messages.exit} /></a>
          <a className="dropdown__close-btn" onClick={handleClick}>x</a>
        </li>
      </ul>
      }
    </li>
  )
}

DropdownUser.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  children: PropTypes.string.isRequired,
  handleClick: PropTypes.func.isRequired
}

export default ToggleOpen(DropdownUser)
