import React from 'react'
import DropzoneS3Uploader from 'react-dropzone-s3-uploader'
import {Icon} from 'react-gosuslugi'
import './file_widget.sass'

const prepareFiles = (value)=> {
  let files = []
  let display = []
  value = Array.isArray(value) ? value : [value]
  value.map((item)=>{
    if(item){
      const file = item.split('?')[0]
      const name = file.split('/')[file.split('/').length-1]
      files.push(file)
      display.push({name, preview: item})
    }
  })

  return {files, display}
}

export default class FileWidget extends React.Component {
  constructor(props){
    super(props)
    this.state = prepareFiles(props.value)
  }

  componentDidMount() {
    const files = this.props.multiple ? this.state.files : this.state.files[0]
    this.props.onChange(files)
  }

  onSubmitHandler = () => {
    if(this.state.files === 0){
      this.setState(() => ({
        arrayNull: 'null'
      }))
    }
  }

  stopPropagation = (e) => {
    e.preventDefault()
    e.stopPropagation()
  }

  deleteUploadFile = (i) => {
    return (e) =>{
      let {files, display} = this.state
      files.splice(i,1)
      display.splice(i,1)
      this.setState({files: files, display: display})
      this.props.onChange(files)
      e.preventDefault()
      e.stopPropagation()
    }
  }

  renderFileUpload = (file, i) => {
    if (file.name.search(/.jpg|.gif|.svg|.jpeg|.png|.tif|.tiff/i) !== -1) {
      return (
        <div onClick={this.stopPropagation} className="drop-zone__content" key={i}>
          <div className="drop-zone__content-img">
            <img src={file.preview} alt={"drop-zone img"} />
          </div>
          <p>
            {decodeURI(file.name)}
          </p>
          <span onClick={this.deleteUploadFile(i)} />
        </div>
      )
    }else if (file.name.toLowerCase().search(/\.(doc|mp3|mp4|ppt|pptf|rtf|txt|wav|xls|xlsx|zip|pdf)(\?|$)/) !== -1) {
      return (
        <div onClick={this.stopPropagation} className="drop-zone__content" key={i}>
          <div className="drop-zone__content-imgFiles">
            <Icon type={file.name.toLowerCase().match(/(doc|mp3|mp4|ppt|pptf|rtf|txt|wav|xls|xlsx|zip|pdf)$/ig)} />
          </div>
          <p>
            {decodeURI(file.name)}
          </p>
          <span onClick={this.deleteUploadFile(i)} />
        </div>
      )
    }
    return (
      <div onClick={this.stopPropagation} className="drop-zone__content" key={i}>
        <div className="drop-zone__content-imgFiles">
          <Icon type='all' />
        </div>
        <p>
          {decodeURI(file.name)}
        </p>
        <span onClick={this.deleteUploadFile(i)} />
      </div>
    )
  }

  render() {
    const { multiple, id, formContext, required, schema} = this.props
    const {title} = schema
    const Text = () =>{
      return <p className="drop-zone__text">Перетащите {multiple ? "файлы" : "файл"} сюда или <span>нажмите</span> для выбора вручную</p>
    }
    return (
      <div className="drop-zone-wrapper">
        <label htmlFor={id}>{title}{required ? "*" : null}</label>
        <DropzoneS3Uploader
          id={id}
          s3Url={`https://s3.${window.location.hostname}`}
          className={`drop-zone ${this.state.arrayNull}`}
          onError={this.onSubmitHandler}
          style={{width: '100%'}}
          upload={{
            signingUrl:"/api/s3/sign",
            signingUrlMethod:"GET",
            signingUrlQueryParams: {
              'guid': formContext.guid,
              field: id
            },
            multiple: multiple,
            scrubFilename: (filename) =>{ return encodeURIComponent(filename.replace(/[\s]+/ig, '_').replace(/[^\wа-яА-ЯёЁ\d_\-\.]+/ig, ''))},
            uploadRequestHeaders:{ 'x-amz-acl': 'public-read' }
          }}
          onFinish={(signResult)=>{
            if (multiple){
              let {files, display} = this.state
              files.push(signResult.signedUrl.split('?')[0])
              display.push(signResult.file)
              this.setState({files: files, display: display})
              this.props.onChange(files)
            } else {
              this.setState({files: [signResult.signedUrl.split('?')[0]], display: [signResult.file]})
              this.props.onChange(signResult.signedUrl.split('?')[0])
              }
            }
          }
        >
          <Text />
          {this.state.display.map(this.renderFileUpload)}
        </DropzoneS3Uploader>
      </div>
    )
  }
}
