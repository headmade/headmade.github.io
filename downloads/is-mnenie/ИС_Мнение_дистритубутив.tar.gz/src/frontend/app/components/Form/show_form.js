import React from 'react'
import Form from "react-jsonschema-form"
import Moment from 'react-moment'
import FileWidget from './show/FileWidget/index'

export default class ShowForm extends React.Component {
  constructor(props){
    super(props)
    this.fields = {
      ...this.fields
    }
    this.uiSchema = {
      title: {
        classNames: "disputes__header"
      }
    }
    this.widgets = {
      TextWidget: (props) => {
        return <p>{props.value}</p>
      },
      EmailWidget: (props) => {
        return <a href={"email:" + props.value}>{props.value}</a>
      },
      FileWidget: FileWidget,
      DateWidget: (props) => {
        return <p><b>{props.label}</b>: <Moment format='YYYY-MM-DD HH:mm'>{props.value}</Moment></p>
      },
      SelectWidget: (props) => {
        return <p>{props.value}</p>
      },
      // ColorWidget: (props) =>{
      //   return <div className="color-picker__select-color" style={{background: `${props.value}`}} />
      // },
      CheckboxWidget: (props) => {
        return <p className="checkbox-caption-show">{props.label}: <span>{props.value ? 'да' : 'нет'}</span></p>
      },
      RadioWidget: (props) => {
        return <p className="checkbox-caption-show">{props.value}</p>
      },
      TextareaWidget: (props) => {
        return <p>{props.value}</p>
      },
      URLWidget: (props) => {
        return <a href={props.value} target="_blank">{props.value}</a>
      }
    }
  }

  customFieldTemplate = (props) => {
    const {classNames, children} = props
    return (
      <div className={classNames}>
        {children}
      </div>
    )
  }

  render(){
    return (
      <Form
        {...this.props}
        className={['show-form', this.props.className].join(' ')}
        fields={this.fields}
        uiSchema={this.uiSchema}
        widgets={this.widgets}
        FieldTemplate={this.customFieldTemplate}
      >
        <br />
      </Form>
    )
  }
}
