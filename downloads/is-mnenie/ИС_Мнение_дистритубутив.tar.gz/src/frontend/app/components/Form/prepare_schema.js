import definitions from './definitions'

export default function prepareSchema(schema){
  return Object.assign({}, schema, {definitions: definitions})
}
