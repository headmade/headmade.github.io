import general from './general'

const definitions = {
  ...general
}

export default definitions
