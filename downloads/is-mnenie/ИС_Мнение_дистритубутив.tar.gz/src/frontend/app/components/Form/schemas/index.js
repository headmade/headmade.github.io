import dispute_schemas from './disputes'
import replic_schemas from './replics'

const schemas = {
  ...dispute_schemas,
  ...replic_schemas
}

export default schemas

