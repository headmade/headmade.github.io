import React from "react"
import OriginalBaseInput from 'react-jsonschema-form/lib/components/widgets/BaseInput'

function BaseInput(props) {
  const {value} = props
  return <OriginalBaseInput {...props} className={value && 'label-min'} />
}

export default BaseInput
