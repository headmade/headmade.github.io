import dispute_schemas from './disputes'
import mergeDeep from '../../../utils/merge_deep'


//TODO: add schemas for all dispute types
const user_replic_schema_base = {
  type: "object",
  required: ["text"],
  properties: {
    participants: {
      // "urvi" - просто потому что там самая полная схема
      ...convertFromDisputeParticipantsToReplicParticipants(dispute_schemas.urvi.properties.participants),
      title: "Задать вопрос (только для участников общественных обсуждений)",
      description: "В целях подтверждения права участвовать в общественных обсуждениях необходимо идентифицировать себя, заполнив одно из следующих полей"
    },
    text: {type: "string", minLength: 10}
  }
}

const replic_question_schema = mergeDeep(user_replic_schema_base, {
  properties: {
    participants: {title: "Задать вопрос (только для участников общественных обсуждений)"},
    text: {title: "Текст вопроса"}
  }
})

const replic_suggestion_schema = mergeDeep(user_replic_schema_base, {
  properties: {
    participants: {title: "Оставить замечание/предложение (только для участников общественных обсуждений)"},
    text: {title: "Текст замечания/предложения"}
  }
})


const servant_decision_schema_base = {
  type: "object",
  title: " ",
  properties: {
    text: {type: "string", minLength: 10}
  }
}


const decision_question_schema = mergeDeep({
  type: "object",
  title: " ",
  required: ['decision', 'response'],
  properties: {
    decision: {
      type: 'string',
      title: 'Решение',
      enum: [ 'accept', 'reject_no_participant', 'reject_obscence', 'reject_bad_data'],
      enumNames: [
        "Принять вопрос",
        "Отказ: не является участником",
        "Отказ: ненормативная лексика",
        "Отказ: предоставлены данные в нечитаемом виде"
      ]
    },
    response: {
      type: 'string',
      title: 'Ответ',
      //default: "Не релевантно",
      enum: [
        "Не релевантно",
        "Да",
        "Нет",
        "Удивительно",
        "Ваш вопрос требует дополнительного исследования"
      ]
    },
    text: {type: "string", minLength: 10, title: "Текст ответа на вопрос"}
  }
}, servant_decision_schema_base)

const decision_suggestion_schema = {
  type: "object",
  title: " ",
  required: ['decision'],
  properties: {
    decision: {
      type: 'string',
      title: 'Решение',
      enum: [ 'accept', 'reject_no_participant', 'reject_obscence', 'reject_irrelevant', 'reject_bad_data'],
      enumNames: [
        "Принять",
        "Отказ: не является участником",
        "Отказ: ненормативная лексика",
        "Отказ: не релевантно",
        "Отказ: предоставлены данные в нечитаемом виде"
      ]
    }
  }
}

export const decision_ui_schema = {
  decision: {
    "ui:widget": "radio"
  }
}

const replic_schemas = {
  replic: {
    expositions: replic_question_schema,
    disputes: replic_suggestion_schema
  },
  decision: {
    question: decision_question_schema,
    suggestion: decision_suggestion_schema
  }
}


function convertFromDisputeParticipantsToReplicParticipants(disputeParticipantsSchema) {
  const replicParticipantsSchema = JSON.parse(JSON.stringify(disputeParticipantsSchema))
  for (let k in replicParticipantsSchema.properties) {
    if (k.startsWith("living")) {
      replicParticipantsSchema.properties[k].type = 'boolean'
    }
  }
  return replicParticipantsSchema
}


/**
 input schema:
 {
   properties: {
     participants: {
       properties: {
         living: {
           type: "string",
           title: "юридическое описание признака living"
         }
 }}}}

 input data:
 {
   participants: {
     living: "конкретные параметры признака living"
   }
 }

 result schema:

 {
   properties: {
     living: {
       type: "string",
       title: "конкретные параметры признака living",      // comes from data
       description: "юридическое описание признака living" // comes from title
     }
 }}

 */

export function prepareParticipantSchema(replicSchema, participantData) {
  replicSchema = JSON.parse(JSON.stringify(replicSchema))
  const participantSchema = replicSchema.properties.participants
  for (let k in participantSchema.properties) {
    if (participantData[k]) {
      let p = participantSchema.properties[k]
      p.description = p.title
      p.title = participantData[k]
      delete p.default
    } else {
      delete participantSchema.properties[k]
    }
  }

  replicSchema.properties.attachments = {'$ref': '#/definitions/attachments', title: 'Приложите подтверждающие документы'}

  //TOFIX: dirty hack: reorder text <-> attachments
  let text = replicSchema.properties.text
  delete replicSchema.properties['text']
  replicSchema.properties.text = text

  return replicSchema
}

export default replic_schemas

