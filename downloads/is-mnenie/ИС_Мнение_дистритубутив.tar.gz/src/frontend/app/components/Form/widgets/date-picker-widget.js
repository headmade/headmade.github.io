import React from 'react'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import 'react-datepicker/dist/react-datepicker-cssmodules.css'
import moment from 'moment'

const dateFormat = 'YYYY-MM-DD'

export default class DatePickerWidget extends React.Component {
  constructor (props) {
    super(props)
    const date = props.value ? moment(props.value, dateFormat) : null
    this.state = {
      startDate: date,
      focus: false
    }
  }

  handleChange = (date) => {
    this.setState({
      startDate: date
    }, this.props.onChange(date.format(dateFormat)))
  }

  blurHandler = () => {
    this.setState(prevState => ({
      focus: !prevState.focus
    }))
  }

  FocusHandler = () => {
    this.setState(prevState => ({
      focus: !prevState.focus
    }))
  }

  render() {
    const {startDate, focus} = this.state
    moment.updateLocale('en', {
      months : {
        format: 'января_февраля_марта_апреля_мая_июня_июля_августа_сентября_октября_ноября_декабря'.split('_'),
        standalone: 'январь_февраль_март_апрель_май_июнь_июль_август_сентябрь_октябрь_ноябрь_декабрь'.split('_')
      },
      monthsShort : {
        format: 'янв._февр._мар._апр._мая_июня_июля_авг._сент._окт._нояб._дек.'.split('_'),
        standalone: 'янв._февр._март_апр._май_июнь_июль_авг._сент._окт._нояб._дек.'.split('_')
      },
      weekdays : {
        standalone: 'воскресенье_понедельник_вторник_среда_четверг_пятница_суббота'.split('_'),
        format: 'воскресенье_понедельник_вторник_среду_четверг_пятницу_субботу'.split('_'),
        isFormat: /\[ ?[Вв] ?(?:прошлую|следующую|эту)? ?\] ?dddd/
      },
      weekdaysShort : 'вс_пн_вт_ср_чт_пт_сб'.split('_'),
      weekdaysMin : 'вс_пн_вт_ср_чт_пт_сб'.split('_')
    })
    return (
      <div
        onFocus={this.FocusHandler}
        onBlur={this.blurHandler}
        className={`datepicker ${startDate ? 'label-min':''} ${focus ? 'label-min':''}`}
      >
        <DatePicker
          id={this.props.id}
          className="datepicker-input"
          dateFormat={dateFormat}
          locale="en-gb"
          selected={startDate}
          onChange={this.handleChange}
          monthsShown={2}
          peekNextMonth
          showMonthDropdown
          showYearDropdown
          dropdownMode="select"
        />
        <label htmlFor={this.props.id} className="datepicker-icon" />
      </div>
    )
  }
}
