const attachments_schema_base = {'$ref': '#/definitions/attachments'}

const dispute_schemas_common = {
  "type": "object",
  "properties": {
    "notification": {
      "type": "object",
      "title": "Оповещение",
      "properties": {
        "major_decree_number": {"type": "string", "title": "Номер постановления мэра"}
      }
    },
    "customer": {
      "type": "string",
      "title": "Заявитель",
      "description": "Инициатор(ы) обсуждения"
    },
    "organization": {
      "type": "string",
      "title": "Наименование организации - организатора обсуждения"
    },
    "organization_address": {
      "type": "string",
      "title": "Адрес организации, ответственной за проведение обсуждения",
      "description": "Адрес организатора общественных обсуждений, куда могут быть представлены предложения и замечания в письменном виде"
    },
    "title_full": {
      "type": "string",
      "title": "Полное наименование обсуждения",
      "description": "Юридически верное наименование"
    },
    "title_short": {
      "type": "string",
      "title": "Краткое название",
      "description": "Используется на сайте при выводе списков; минимум слов, передающих суть предмета обсуждения"
    },
    "object_description": {
      "type": "string",
      "title": "Описание объекта обсуждения",
      "description": "Например: адрес, район, проводимые работы, название ТЦ, ЖК, ТРК или иное описание; используется в постановлении мэра и других документах"
    },
    "notification_published_at": {
      "type": "string",
      "format": "date",
      "title": "Дата публикации оповещения"
    },
    "dispute_started_at": {
      "type": "string",
      "format": "date",
      "title": "Дата начала экспозиции, обсуждений и приёма замечаний и предложений"
    },
    "dispute_ended_at": {
      "type": "string",
      "format": "date",
      "title": "Дата завершения экспозиции, обсуждений и приёма замечаний и предложений"
    },
    "protocolled_at": {
      "type": "string",
      "format": "date",
      "title": "Дата оформления протокола"
    },
    "conclusion_prepared_at": {
      "type": "string",
      "format": "date",
      "title": "Дата оформления заключения о результатах"
    },
    "conclusion_published_at": {
      "type": "string",
      "format": "date",
      "title": "Дата публикации заключения о результатах"
    },
    "system_location": {
      "type": "string",
      "title": "Адрес помещения, в котором предоставляется доступ к ИС ОО"
    },
    "system_location_schedule": {
      "type": "string",
      "title": "Информация о режиме работы места посещения ИС ОО"
    },
    "participant_registration_location": {
      "type": "string",
      "title": "Адрес помещения, в котором принимаются предложения и замечания",
      "description": "Адрес помещения, куда могут быть представлены предложения и замечания путём записи в книге (журнале) учёта посетителей экспозиции проекта, подлежащего рассмотрению на общественных обсуждениях"
    }
    //"participant_registration_location_schedule": {
      //"type": "string",
      //"title": "Информация о режиме работы места нахождения книги (журнала) учёта посетителей"
    //}
  }
}

const pzz_data_schema = {
  "type": "object",
  "title": "Предмет обсуждения",
  "properties": {
    "target": { "type": "string", "title": "Назначение", description: "Для чего выполняется перезонирование" },
    "rezones": {
      "type": "array",
      "title": "",
      "minItems": 1,
      "items": {
        "type": "object",
        "title": "Участок",
        "properties": {
          "zone": {
            "type": "object",
            "title": "",
            "properties": {
              "cadastre_number": { "type": "string", "title": "Кадастровый номер" },
              "area": { "type": "number", "title": "Площадь участка (кв.м)" },
              "location": { "type": "string", "title": "Расположение", decription: 'Адрес, район или иное описание расположения участка'}
            }
          },
          "zone_types_from": {
            "type": "array",
            "title": "Исходные зоны",
            "minItems": 1,
            //"uniqueItems": true,
            "items": {
              //"enum": [
                //"СХ",
                //"Ж2",
                //"Ж4",
                //"Р2"
              //],
              "type": "string"
            }
          },
          "zone_type_to": {
            //"enum": [
              //"СХ",
              //"Ж2",
              //"Ж4",
              //"Р2"
            //],
            "type": "string",
            "title": "Назначить зону"
          }
        }
      }
    }
  }
}

const urvi_data_schema = {
  "type": "object",
  "title": "Предмет обсуждения",
  "properties": {
    "zones": {
      "type": "array",
      "title": "",
      "minItems": 1,
      "items": {
        "type": "object",
        "title": "Участок",
        "properties": {
          "cadastre_number": {
            "type": "string",
            "title": "Кадастровый номер"
          },
          "area": {
            "type": "number",
            "title": "Площадь участка (кв.м)"
          },
          "location": {
            "type": "string",
            "title": "Расположение"
          }
        }
      }
    },
    "zone_type": {
      //"enum": [
        //"СХ",
        //"Ж2",
        //"Ж4",
        //"Р2"
      //],
      "type": "string",
      "title": "Тип зоны"
    },
    "location": {
      "type": "string",
      "title": "Условно-разрешённый вид использования земельного участка"
    },
    "permitted_use_code": {
      //"enum": [
        //"1",
        //"1.1",
        //"1.2",
        //"1.2.1"
      //],
      "type": "string",
      "title": "Код вида использования"
    }
  }
}

const deviation_data_schema = {
  "type": "object",
  "title": "Предмет обсуждения",
  "properties": {
    "reasons": {
      "type": "array",
      "items": {
        "enum": [
          "Причина-1",
          "Причина-2",
          "Причина-3"
        ],
        "type": "string"
      },
      "title": "Причина запроса",
      "minItems": 1,
      "uniqueItems": true
    },
    "margins": {
      "type": "object",
      "title": "Границы участка",
      "properties": {
        "linear": {
          "type": "array",
          "title": "Линейные сегменты",
          "items": {
            "type": "object",
            "title": "Линейный сегмент",
            "properties": {
              "from": {
                "type": "number",
                "title": "от точки"
              },
              "to": {
                "type": "number",
                "title": "до точки"
              },
              "distance": {
                "type": "number",
                "title": "расстояние до границы",
                "description": "в метрах"
              }
            }
          }
        },
        "radial": {
          "type": "array",
          "title": "Радиальные сегменты",
          "items": {
            "type": "object",
            "title": "Радиальные сегмент",
            "properties": {
              "from": {
                "type": "number",
                "title": "от точки"
              },
              "distance": {
                "type": "number",
                "title": "расстояние до границы",
                "description": "в метрах"
              }
            }
          }
        }
      }
    },
    "density_of_construction": {
      "type": "object",
      "title": "Плотность застройки",
      "properties": {
        "value": {
          "type": "number",
          "title": " ",
          "description": "кв.м/га"
        }
      }
    },
    "percentage_of_construction": {
      "type": "object",
      "title": "Процент застройки",
      "properties": {
        "value": {
          "type": "number",
          "title": " ",
          "description": "в процентах"
        }
      }
    },
    "parking": {
      "type": "array",
      "title": "Паркинг",
      "items": {
        "type": "object",
        "properties": {
          "zone": {
            "type": "object",
            "title": "На участок",
            "properties": {
              "cadastre_number": {
                "type": "string",
                "title": "Кадастровый номер"
              },
              "area": {
                "type": "number",
                "title": "Площадь участка (кв.м)"
              },
              "location": {
                "type": "string",
                "title": "Расположение"
              }
            }
          },
          "count": {
            "type": "number",
            "title": "кол-во перенесённых машиномест"
          }
        }
      }
    },
    "height": {
      "type": "object",
      "title": "Высота",
      "properties": {
        "value": {
          "type": "number",
          "title": " ",
          "description": "Желаемая высота"
        }
      }
    }
  }
}

const participant_1_properties = {
  living_in_disput_territory: {type: "string", title: "граждане, постоянно проживающие на территории", default: "граждане, постоянно проживающие на территории"},
  owner_land_in_disput_territory: {type: "string", title: "правообладатели земельных участков, находящихся в границах этой территории", default: "правообладатели земельных участков, находящихся в границах этой территории"},
  owner_building_in_disput_territory: {type: "string", title: "правообладатели объектов капитального строительства, находящихся в границах этой территории", default: "правообладатели объектов капитального строительства, находящихся в границах этой территории"},
  owner_room_in_disput_territory: {type: "string", title: "правообладатели помещений, являющихся частью объектов капитального строительства, находящихся в границах этой территории", default: "правообладатели помещений, являющихся частью объектов капитального строительства, находящихся в границах этой территории"}
}

const participant_1_schema = {
  type: "object",
  title: "Участники общественных обсуждений",
  properties: {
    ...JSON.parse(JSON.stringify(participant_1_properties))
  }
}

const participant_2_schema = {
  type: "object",
  title: "Участники общественных обсуждений",
  properties: {
    ...JSON.parse(JSON.stringify(participant_1_properties)),
    living_in_adjacent_disput_territory: {type: "string", title: "граждане, постоянно проживающие на территории смежных участков", default: "граждане, постоянно проживающие на территории смежных участков"},
    owner_land_in_adjacent_disput_territory: {type: "string", title: "правообладатели земельных участков, находящихся в границах территории смежных участков", default: "правообладатели земельных участков, находящихся в границах территории смежных участков"},
    owner_building_in_adjacent_disput_territory: {type: "string", title: "правообладатели объектов капитального строительства, находящихся в границах территории смежных участков", default: "правообладатели объектов капитального строительства, находящихся в границах территории смежных участков"},
    owner_room_in_adjacent_disput_territory: {type: "string", title: "правообладатели помещений, являющихся частью объектов капитального строительства, находящихся в границах территории смежных участков", default: "правообладатели помещений, являющихся частью объектов капитального строительства, находящихся в границах территории смежных участков"},
    living_in_risk_disput_territory: {type: "string", title: "граждане, постоянно проживающие на территории участков, подверженных риску негативного воздействия на окружающую среду", default: "граждане, постоянно проживающие на территории участков, подверженных риску негативного воздействия на окружающую среду"},
    owner_land_in_risk_disput_territory: {type: "string", title: "правообладатели земельных участков, находящихся в границах подверженной риску территории", default: "правообладатели земельных участков, находящихся в границах подверженной риску территории"},
    owner_building_in_risk_disput_territory: {type: "string", title: "правообладатели объектов капитального строительства, находящихся в границах подверженной риску территории", default: "правообладатели объектов капитального строительства, находящихся в границах подверженной риску территории"},
    owner_room_in_risk_disput_territory: {type: "string", title: "правообладатели помещений, являющихся частью объектов капитального строительства, находящихся в границах подверженной риску территории", default: "правообладатели помещений, являющихся частью объектов капитального строительства, находящихся в границах подверженной риску территории"}
  }
}


const dispute_schemas = {
  genplan: JSON.parse(JSON.stringify(dispute_schemas_common)),
  pzz: JSON.parse(JSON.stringify(dispute_schemas_common)),
  deviation: JSON.parse(JSON.stringify(dispute_schemas_common)),
  urvi: JSON.parse(JSON.stringify(dispute_schemas_common)),
  planning: JSON.parse(JSON.stringify(dispute_schemas_common)),
  boundary: JSON.parse(JSON.stringify(dispute_schemas_common))
}

// Set dispute object data
dispute_schemas.pzz.properties.data = pzz_data_schema
dispute_schemas.urvi.properties.data = urvi_data_schema
dispute_schemas.deviation.properties.data = deviation_data_schema

// Set dispute attachments
dispute_schemas.genplan.properties.attachments = JSON.parse(JSON.stringify(attachments_schema_base))
dispute_schemas.pzz.properties.attachments = JSON.parse(JSON.stringify(attachments_schema_base))
dispute_schemas.planning.properties.attachments = JSON.parse(JSON.stringify(attachments_schema_base))
dispute_schemas.boundary.properties.attachments = JSON.parse(JSON.stringify(attachments_schema_base))
dispute_schemas.urvi.properties.attachments = JSON.parse(JSON.stringify(attachments_schema_base))
dispute_schemas.deviation.properties.attachments = JSON.parse(JSON.stringify(attachments_schema_base))

// Set dispute attachments
dispute_schemas.genplan.properties.participants = JSON.parse(JSON.stringify(participant_1_schema))
dispute_schemas.pzz.properties.participants = JSON.parse(JSON.stringify(participant_1_schema))
dispute_schemas.planning.properties.participants = JSON.parse(JSON.stringify(participant_1_schema))
dispute_schemas.boundary.properties.participants = JSON.parse(JSON.stringify(participant_1_schema))

dispute_schemas.urvi.properties.participants = JSON.parse(JSON.stringify(participant_2_schema))
dispute_schemas.deviation.properties.participants = JSON.parse(JSON.stringify(participant_2_schema))

export default dispute_schemas

