import React from 'react'
import {Button, Container, Col} from 'react-gosuslugi'

export default class ArrayFieldTemplate extends React.Component{
  hasRemove(element, minItems, length) {
    return element.hasRemove && (length > (minItems || 0))
  }

  render() {
    const {className, items, onAddClick, canAdd, schema} = this.props
    const {minItems} = schema
    return (
      <div className={className}>
        {items &&
        items.map(element => (
          <div className="array-wrapper" key={element.index}>
            <Container>
              <Col xs={6} sm={10} md={20} lg={20}>{element.children}</Col>
              <Col xs={6} sm={2} md={4} lg={4}>
                <div className="btn-wrapper">
                  {element.hasMoveUp && (
                    <div className="upButton" onClick={element.onReorderClick(element.index, element.index - 1)} />
                  )}
                  {element.hasMoveDown && (
                    <div className="dwButton" onClick={element.onReorderClick(element.index, element.index + 1)} />
                  )}
                  {this.hasRemove(element, minItems, items.length) && (
                    <div className="deleteButton" onClick={element.onDropIndexClick(element.index)} />
                  )}
                </div>
              </Col>
            </Container>
          </div>
        ))
        }
        {canAdd && (
          <div className="addBtn-wrapper">
            <Container>
              <Col xs={3} sm={3} md={6} lg={6}>
                <Button onClick={onAddClick} bsSize="large">
                  <span className="addButton" /> Добавить
                </Button>
              </Col>
            </Container>
          </div>
        )}
      </div>
    )
  }
}
