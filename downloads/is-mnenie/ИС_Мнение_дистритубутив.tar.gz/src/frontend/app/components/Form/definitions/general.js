const general = {
  file: {type: "string", format: "data-url", title: "Файл"},

  file_with_description: {
    type: "object",
    properties: {
      description: {type: "string", title:"Описание"},
      url: {'$ref': '#/definitions/file'}
    }
  },

  attachments: {
    type: "array",
    title: "Прилагаемые файлы",
    minItems: 1,
    items: {
      type: "object",
      properties: {
        description: {type: "string", title:"Описание файла"},
        url: {'$ref': '#/definitions/file'}
      }
    }
  }
}

export default general
