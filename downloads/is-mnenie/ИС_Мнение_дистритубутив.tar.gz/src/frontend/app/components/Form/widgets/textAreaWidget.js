import React from "react"
import OriginalTextAreaWidget from 'react-jsonschema-form/lib/components/widgets/TextareaWidget'

function TextareaWidget(props) {
  const {value, id, label, required} = props
  let value_style = value ? 'label-min' : ''
  return (
    <div className={`textarea ${value_style}`}>
      <OriginalTextAreaWidget {...props}  />
      <label htmlFor={id}>{label}{required ? "*" : null}</label>
    </div>
  )
}

export default TextareaWidget