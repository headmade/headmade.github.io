import React from "react"
import OriginalSelectWidget from 'react-jsonschema-form/lib/components/widgets/SelectWidget'

function SelectWidget(props) {
  const {value, id, label, required} = props
  let value_style = value ? 'label-min' : ''
  return (
    <div className={`select ${value_style}`}>
      <span className='pseudo' />
      <OriginalSelectWidget {...props} className={value_style} />
      <label htmlFor={id}>{label}{required ? "*" : null}</label>
    </div>
  )
}

export default SelectWidget