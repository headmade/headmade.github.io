import React from 'react'
import {Thumbnail, Container, Col, Icon, Loader} from 'react-gosuslugi'
import LazyLoad from 'react-lazy-load'
import brokenIcon from './brokenImg.svg'

export default class FileWidget extends React.PureComponent {
  constructor(props){
    super(props)
    this.state = { file:'', open: false, loaded: true, error: false}
    const host = window.location.hostname === 'localhost' ? 'dispute.kzn.ru' : window.location.hostname
    this.imageproxyUrl = `https://imageproxy.s3.${host}`
  }

  onErrorImage = () => {
    this.setState({
      error: true
    })
  }

  getSrcImages = (imageproxyUrl, options ,file) => {
    return `${imageproxyUrl}/${options}/${file}`
  }


  toggleOpen = (file) => {
    this.setState({file, open: true})
  }

  toggleClose = () => {
    this.setState({file:'', open: false})
  }

  loadImage = () => {
    this.setState({
      loaded: false
    })
  }

  render(){
    const {value} = this.props
    const {loaded, error, open} = this.state
    if (Array.isArray(value)){
      return (
        <Container>
          {value.map((file)=>{
            if (!file){
              return ''
            }
            if (file.toLowerCase().match(/(.jpg|.jpeg|.png|.gif|.tif|.svg|.tiff)\?/)){
              return (
                <Col key={file} xs={1} sm={3} md={6} lg={6} >
                  {error ?
                    <div className="brokenImg-wrapper">
                      <img src={brokenIcon} alt="brokenIcon" />
                    </div>
                    :
                    <div onClick={this.toggleOpen.bind(this, file)} className="thumbnail-wrapper">
                      {loaded && <Loader />}
                      <LazyLoad>
                        <Thumbnail src={this.getSrcImages(this.imageproxyUrl,"150x,q60", file)} onLoad={this.loadImage} onError={this.onErrorImage} />
                      </LazyLoad>
                    </div>
                  }
                  {open &&
                    <div onClick={this.toggleClose} className="thumbnailX2-wrapper thumbnailX2-wrapper-on" >
                      <img src={this.getSrcImages(this.imageproxyUrl,"1500x,q60", this.state.file)} onLoad={this.loadImage} alt={this.state.file} />
                      {loaded && <Loader />}
                    </div>
                  }
                </Col>
              )
            }
            return (
              <Col key={file} xs={1} sm={3} md={6} lg={6} >
                <li className="docs__list-item">
                  <div className="wrapper-list-item__img">
                    <Icon type={file.toLowerCase().match(/(jpg|gif|svg|jpeg|png|tif|tiff|doc|mp3|mp4|ppt|pptf|rtf|txt|wav|xls|xlsx|zip|pdf)/ig)} />
                  </div>
                  <div className="wrapper-list-item__text">
                    <p>{file && file.split('?').shift().split('/').pop()}</p>
                    <a href={file}>Скачать</a>
                  </div>
                </li>
              </Col>
            )})
          }
        </Container>
      )
    }
    if (!value){
      return <br />
    }
    if (value.toLowerCase().match(/(.jpg|.jpeg|.png|.gif|.svg|.tif|.tiff)\?/)){
      return (
        <Container>
          <Col xs={6} sm={12} md={24} lg={24} >
            {error ?
              <div className="brokenImg-wrapper">
                <img src={brokenIcon} alt="brokenIcon" />
              </div>
              :
              <div onClick={this.toggleOpen.bind(this, value)} className="thumbnail-wrapper">
                {loaded && <Loader />}
                <LazyLoad>
                  <Thumbnail src={this.getSrcImages(this.imageproxyUrl,"150x,q60", value)} onLoad={this.loadImage} onError={this.onErrorImage} />
                </LazyLoad>
              </div>
            }
            {open &&
              <div onClick={this.toggleClose} className="thumbnailX2-wrapper thumbnailX2-wrapper-on" >
                <img src={this.getSrcImages(this.imageproxyUrl,"1500x,q60", this.state.file)} onLoad={this.loadImage} alt={this.state.file} />
                {loaded && <Loader />}
              </div>
            }
          </Col>
        </Container>
      )
    }
    else {
      return (
        <Container>
          <Col xs={6} sm={12} md={24} lg={24} >
            <li className="docs__list-item">
              <div className="wrapper-list-item__img">
                <Icon type={value.toLowerCase().match(/(jpg|gif|svg|jpeg|png|tif|tiff|doc|mp3|mp4|ppt|pptf|rtf|txt|wav|xls|xlsx|zip|pdf)/ig)} />
              </div>
              <div className="wrapper-list-item__text">
                <p>{value && value.split('?').shift().split('/').pop()}</p>
                <a href={value}>Скачать</a>
              </div>
            </li>
          </Col>
        </Container>
      )
    }
  }
}
