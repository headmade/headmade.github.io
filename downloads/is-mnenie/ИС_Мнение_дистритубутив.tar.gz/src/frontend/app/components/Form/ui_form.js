import React from 'react'
import Form from "react-jsonschema-form"
import FileWidget from './widgets/file_widget/index'
import BaseInput from './widgets/baseInput'
import DatePickerWidget from './widgets/date-picker-widget'
import SelectWidget from './widgets/select_widget'
import TextareaWidget from './widgets/textAreaWidget'
import ArrayFieldTemplate from './fields/arrayTemplate'
import './Math.uuid'


const ERROR_TYPE = {
  base: title => `в поле ${title} ошибка`,
  minLength: (title, params) => `поле ${title} должно быть минимум ${params.limit} символов`,
  required: title => `поле ${title} не может быть пустым`,
  format: title => `поле ${title} имеет некорректный формат`,
  type: title => `поле ${title} имеет некорректный тип`,
  oneOf: title => `поле ${title} имеет некорректный тип (oneOf)`
}

export default class UIForm extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      formData: props.formData
    }
    this.formContext = {guid: Math.uuid()}

    let work_directions = {
      test2: {"ui:widget": "file"},
      work_directions_road: {"ui:widget": "checkboxes"},
      work_directions_road_sidewalk: {"ui:widget": "checkboxes"},
      work_directions_road_green: {"ui:widget": "checkboxes"},
      work_directions_local_road: {"ui:widget": "checkboxes"},
      work_directions_local_road_green: {"ui:widget": "checkboxes"},
      work_directions_green: {"ui:widget": "checkboxes"},
      work_directions_sidewalk: {"ui:widget": "checkboxes"},
      work_directions_sidewalk_green: {"ui:widget": "checkboxes"},
      work_directions_gnb: {"ui:widget": "checkboxes"},
      work_directions_comments: {"ui:widget": "textarea"}
    }
    //TODO нужно исправить поле преобразования Definitions
    this.UISchema = {
      ...work_directions,
      result_data: { ...work_directions },
      test2: {"ui:widget": "file"},
      work_directions_comments: {"ui:widget": "textarea"},
      reject_reasons: {"ui:widget": "checkboxes"},
      application_missings: {"ui:widget": "checkboxes"},
      external_system_request_types: {"ui:widget": "checkboxes"},
      confirmations: {"ui:widget": "checkboxes"}
    }

    this.widgets = {
      FileWidget: FileWidget,
      SelectWidget: SelectWidget,
      BaseInput: BaseInput,
      DateWidget: DatePickerWidget,
      TextareaWidget: TextareaWidget
    }
    this.onChange = this.onChange.bind(this)
  }
  onChange(event){
    this.setState({"formData": event.formData}, ()=>{
      this.props.onChange && this.props.onChange(this.state.formData)
    })
  }

  onKeyPress(event){
    if(event.target.tagName==='TEXTAREA'){
      return
    }
    if(event.key == 'Enter'){
      event.preventDefault()
      event.stopPropagation()
      const form = event.target.form
      let i = Array.prototype.indexOf.call(form, event.target)
      for(let el = form.elements[++i]; el; el=form.elements[++i]) {
        if (el.tagName == 'INPUT' || el.tagName == 'TEXTAREA') {
          el.focus()
          return
        }
      }
    }
  }

  errorMessage(name, title, params) {
    const errorType = typeof ERROR_TYPE[name] === 'function' ? ERROR_TYPE[name] : ERROR_TYPE['base']
    return errorType(title, params)
  }


  transformErrors = (errors)=>{
    //Dirty hack error remove
    const ff = (value) => {
      if (value.name=='format' && value.message.includes('data-url')){
        return false
      }
      return true
    }
    return errors.filter(ff).map((error) => {
      let property = error.property.split('.')
      const name = error.name
      const plen = property.length
      if (plen > 2){
        property = property.slice(0,plen-1)
      }
      property = property.join('.')
      //const title = error.schema.title||''
      return {
        ...error,
        property: property,
        stack: this.errorMessage(name, error.property, error.params),
        message: this.errorMessage(name, '', error.params)
      }
    })
  }

  customFieldTemplate(props) {
    const {id, classNames, label, help, required, description, errors, children} = props
    let description_text = description.props.description
    return (
      <div className={classNames + " input-wrapper "}>
        {children}
        <label htmlFor={id}>{label}{required ? "*" : null}</label>
        {description_text &&
          <div>
            <div className={"info-tooltip"}>?</div>
            <div className={"info-tooltip-content"}>{description_text}</div>
          </div>
        }
        {errors &&
          <div className='errors-wrapper' style={{order:-1}}>{errors}</div>
        }
        {help}
      </div>
    )
  }

  render(){
    return (
      <div onKeyPress={this.onKeyPress}>
        <Form
          className="form-wrapper"
          showErrorList={false}
          noHtml5Validate
          {...this.props}
          ArrayFieldTemplate={ArrayFieldTemplate}
          transformErrors={this.transformErrors}
          onSubmit={this.props.onSubmit}
          widgets={this.widgets}
          fields={this.fields}
          schema={Object.assign({},this.props.schema, {title: undefined})}
          onChange={this.onChange}
          formData={this.state.formData}
          formContext={this.formContext}
          FieldTemplate={this.customFieldTemplate}
        />
      </div>
    )
  }
}
