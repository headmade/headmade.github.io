import React from 'react'
import PropTypes from 'prop-types'
import {FormattedMessage} from 'react-intl'
import messages from './messages'

const Favorite = ({isFavorite, onToggleFavorite, disputeId}) => {
  // onToggleFavorite = () => {
  //   fetch("/api//favorite_requests.json",{method:"POST", data: {disputeId}})
  // }

  return (
    <div
      onClick={() => onToggleFavorite(disputeId)}
      className="favorite__item"
    >
      <svg xmlns="http://www.w3.org/2000/svg" version="1.1" x="0px" y="0px" viewBox="0 0 53.867 53.867">
        <polygon style={{stroke: "#303030", fill: isFavorite ? "#EFCE4A" : "#fff"}} points="26.934,1.318 35.256,18.182 53.867,20.887 40.4,34.013 43.579,52.549 26.934,43.798   10.288,52.549 13.467,34.013 0,20.887 18.611,18.182 " />
      </svg>
      <FormattedMessage {...messages.Favorite} />
    </div>
  )
}

Favorite.propTypes = {
  isFavorite: PropTypes.bool,
  onToggleFavorite: PropTypes.func,
  disputeId: PropTypes.number
}

export default Favorite
