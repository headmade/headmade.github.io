import {defineMessages} from 'react-intl'

export default defineMessages({
  Comment: {
    id: 'app.components.Favorites.Comment',
    defaultMessage: 'Замечания и предложения'
  },
  Questions: {
    id: 'app.components.Favorites.Questions',
    defaultMessage: 'Вопросы'
  },
  Favorite: {
    id: 'app.components.Favorites.Favorite',
    defaultMessage: 'Избранное'
  },
  Subscribe: {
    id: 'app.components.Favorites.Subscribe',
    defaultMessage: 'Поделиться'
  }
})
