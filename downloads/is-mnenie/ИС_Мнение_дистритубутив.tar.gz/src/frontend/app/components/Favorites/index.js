import React from 'react'
import PropTypes from "prop-types"
// import Favorite from './Favorite'
import Comment from './Comment'
// import Subscribe from './Subscribe'

import "./Favorite.sass"

const Favorites = ({ disputeId, path,  mode}) => {
  return (
    <div className="favorite">
      {/*<Favorite disputeId={disputeId} onToggleFavorite={onToggleFavorite} isFavorite={isFavorite} />*/}
      <Comment path={path} disputeId={disputeId} mode={mode} />
      {/*<Subscribe />*/}
    </div>
  )
}

Favorites.propTypes = {
  // isFavorite: PropTypes.bool,
  // onToggleFavorite: PropTypes.func,
  disputeId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  path: PropTypes.string,
  mode: PropTypes.string
}

export default Favorites
