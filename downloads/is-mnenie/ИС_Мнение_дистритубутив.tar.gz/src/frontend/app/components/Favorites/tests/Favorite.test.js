import React from 'react'
import renderer from 'react-test-renderer'
import {shallow} from 'enzyme'
import {IntlProvider, FormattedMessage} from 'react-intl'

import Favorite from '../Favorite'
import messages from '../messages'

test('Favorite with params', () => {
  const component = renderer.create(
    <IntlProvider locale="en">
      <Favorite isFavorite disputeId={1} onToggleFavorite={()=>{}} />
    </IntlProvider>
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})

describe('<Favorite />', () => {
  it('should render the page message', () => {
    const renderedComponent = shallow(<Favorite isFavorite disputeId={1} onToggleFavorite={()=>{}} />)
    expect(renderedComponent
      .contains(<FormattedMessage {...messages.Favorite} />))
      .toEqual(true)
  })
})


