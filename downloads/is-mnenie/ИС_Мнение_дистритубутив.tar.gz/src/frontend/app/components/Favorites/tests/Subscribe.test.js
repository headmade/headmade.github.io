import React from 'react'
import renderer from 'react-test-renderer'
import {shallow} from 'enzyme'
import {IntlProvider, FormattedMessage} from 'react-intl'

import Subscribe from '../Subscribe'
import messages from '../messages'

test('Subscribe with params', () => {
  const component = renderer.create(
    <IntlProvider locale="en">
      <Subscribe />
    </IntlProvider>
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})

describe('<Favorite />', () => {
  it('should render the page message', () => {
    const renderedComponent = shallow(<Subscribe />)
    expect(renderedComponent
      .contains(<FormattedMessage {...messages.Subscribe} />))
      .toEqual(true)
  })
})


