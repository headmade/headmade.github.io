import React from 'react'
import { MemoryRouter } from 'react-router'
import renderer from 'react-test-renderer'
import {shallow} from 'enzyme'
import {IntlProvider, FormattedMessage} from 'react-intl'

import Comment from '../Comment'
import messages from '../messages'

test('Comment Link', () => {
  const component = renderer.create(
    <IntlProvider locale="en">
      <MemoryRouter>
        <Comment disputeId="1" path="/" />
      </MemoryRouter>
    </IntlProvider>
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})

test('Comment Div', () => {
  const component = renderer.create(
    <IntlProvider locale="en">
      <Comment disputeId="1" path="/disputes/:id" />
    </IntlProvider>
  )
  let tree = component.toJSON()
  expect(tree).toMatchSnapshot()
})

describe('<Comment />', () => {
  it('should render the page message', () => {
    const renderedComponent = shallow(<Comment disputeId="1" path="/" />)
    expect(renderedComponent
      .contains(<FormattedMessage {...messages.Comment} />))
      .toEqual(true)
  })
})


