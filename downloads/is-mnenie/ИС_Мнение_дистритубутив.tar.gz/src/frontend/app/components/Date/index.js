import React from 'react'
import PropTypes from "prop-types"
import Moment from 'react-moment'
import 'moment/locale/ru'
import './Date.sass'


const Date = ({children, format='DD.MM.YYYY', locale="ru", marginLeftNone, marginRightNone}) => {
  if (children) {
    return (
      <span className={`date_wrapper ${marginLeftNone?"date_wrapper--margin_left_none":""} ${marginRightNone?"date_wrapper--margin_right_none":""}`}>
        <Moment format={format} locale={locale}>{children}</Moment>
      </span>
    )
  }
  return null
}

Date.propTypes = {
  format: PropTypes.string,
  locale: PropTypes.string,
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]),
  marginLeftNone: PropTypes.bool,
  marginRightNone: PropTypes.bool
}

export default Date
