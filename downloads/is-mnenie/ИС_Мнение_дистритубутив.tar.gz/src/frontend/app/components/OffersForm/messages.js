import {defineMessages} from 'react-intl'

export default defineMessages({
  Send: {
    id: 'app.components.OffersForm.Send',
    defaultMessage: 'Отправить'
  }
})
