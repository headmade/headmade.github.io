import React, {PureComponent} from 'react'
import {Button} from 'react-gosuslugi'
import PropTypes from 'prop-types'
 import {fromJS} from "immutable"
import {FormattedMessage} from 'react-intl'
import messages from './messages'
import StatusShow from "../../components/StatusShow"
import UIForm from "../../components/Form/ui_form"
import schemas from "../../components/Form/schemas"
import {prepareParticipantSchema} from "../../components/Form/schemas/replics"
import prepareSchema from "../../components/Form/prepare_schema"

export default class OffersForm extends PureComponent {
  static propTypes = {
    dispute: PropTypes.object.isRequired,
    mode: PropTypes.string.isRequired,
    formError: PropTypes.bool,
    formSent: PropTypes.bool,
    formSending: PropTypes.bool,
    onAddComment: PropTypes.func.isRequired
  }

  onSubmit = (event) => {
    const {dispute, onAddComment, mode} = this.props
    const formData = event.formData
    const disputeId = dispute && dispute.id
    onAddComment(fromJS(formData), mode, disputeId)
  }

  render() {
    const {dispute, formSending, mode, formError, formSent} = this.props
    const {participants} = dispute
    const participantSchema = prepareParticipantSchema(schemas['replic'][mode], participants)
    return (
      <div className="input-wrapper">
        <UIForm onSubmit={this.onSubmit} schema={prepareSchema(participantSchema)} >
          <Button bsStyle="success" bsSize="large" type="submit" disabled={formSending} >
            <StatusShow sending={formSending} sent={formSent} error={formError} />
            <FormattedMessage {...messages.Send} />
          </Button>
        </UIForm>
      </div>
    )
  }
}
