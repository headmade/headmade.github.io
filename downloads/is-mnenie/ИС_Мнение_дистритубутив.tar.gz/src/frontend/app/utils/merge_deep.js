/**
 * Usage:
 *
 * import mergeDeep from '../../../utils/merge_deep'
 * console.log('merge', mergeDeep({d: {a: {b: 1, c: 3}}}, {d: {a: {c: 4}}}))
 */

/**
 * Simple object check.
 * @param item
 * @returns {boolean}
 */
export function isObject(item) {
  return (item && typeof item === 'object' && !Array.isArray(item))
}


export default function mergeDeep(target, source) {
  let output = JSON.parse(JSON.stringify(target))
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target))
          Object.assign(output, { [key]: source[key] })
        else
          output[key] = mergeDeep(target[key], source[key])
      } else {
        Object.assign(output, { [key]: source[key] })
      }
    })
  }
  return output
}

