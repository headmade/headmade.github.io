import React from 'react'

export default Component => class Accordion extends React.Component {
  state ={
    openItemId: ""
  }

  render(){
    return <Component {...this.props} {...this.state} toggleOpenItem={this.toggleOpenItem} />
  }

  toggleOpenItem = openItemId => {
    this.setState({
      openItemId: openItemId === this.state.openItemId ? "" : openItemId
    })
  }
}
